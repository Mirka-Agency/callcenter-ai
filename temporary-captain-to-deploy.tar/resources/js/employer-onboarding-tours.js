/** @typedef {{ selector?: string, title: string, content: string, placement?: string, align?: string, route?: string, center?: boolean, fab?: boolean }} TourStep */

/** @type {Record<string, { label: string, steps: TourStep[] }>} */
export const employerPageTours = {
    'employer.dashboard': {
        label: 'داشبورد',
        steps: [
            {
                selector: '[data-tour="dashboard-hero"]',
                title: 'نمای کلی شرکت',
                content: 'نام سازمان، تعداد تماس‌های امروز و بازه نمای کلی داشبورد را اینجا می‌بینید.',
            },
            {
                selector: '[data-tour="dashboard-stats"]',
                title: 'شاخص‌های سریع',
                content: 'کارشناسان فعال، تماس‌های تحلیل‌شده، میانگین امتیاز تیم، کیفیت لید و رضایت مشتری.',
            },
            {
                selector: '[data-tour="dashboard-quality"]',
                title: 'روند کیفیت تیم',
                content: 'نمودار روند میانگین امتیاز مکالمه. روی هر نقطه کلیک کنید تا دلیل افزایش یا کاهش و کارشناسان مؤثر را ببینید.',
            },
            {
                selector: '[data-tour="dashboard-agents"]',
                title: 'عملکرد کارشناسان',
                content: 'کارت هر کارشناس را ببینید، فیلتر برترین‌ها یا نیازمند توجه را بزنید و برای جزئیات روی کارت کلیک کنید.',
            },
            {
                selector: '[data-tour="dashboard-opportunities"]',
                title: 'فرصت‌های معاملاتی جدید',
                content: 'لیدهای باکیفیت ۳۰ روز اخیر را اینجا ببینید و برای بستن فروش پیگیری کنید.',
            },
            {
                selector: '[data-tour="dashboard-sentiment-customers"]',
                title: 'مشتریان راضی و ناراضی',
                content: 'بین تب مشتریان راضی و ناراضی جابه‌جا شوید و برای جزئیات روی هر مشتری کلیک کنید.',
            },
            {
                selector: '[data-tour="dashboard-forgotten-followups"]',
                title: 'پیگیری‌های فراموش‌شده',
                content: 'با برچسب همه، فوری یا در حال تأخیر تماس‌ها را جدا کنید، جزئیات را باز کنید و برای اقدام به تحلیل تماس بروید.',
            },
        ],
    },
    'employer.intelligence.performance': {
        label: 'عملکرد کارشناسان',
        steps: [
            {
                selector: '[data-tour="page-header"]',
                title: 'عملکرد کارشناسان',
                content: 'رتبه‌بندی، مقایسه و ارزیابی مهارت تیم. از همین بالا می‌توانید کارشناس جدید اضافه کنید یا خروجی PDF بگیرید.',
            },
            {
                selector: '[data-tour="performance-filters"]',
                title: 'فیلتر بازه زمانی',
                content: 'بازه زمانی را انتخاب کنید. خروجی CSV/Excel/PDF هم از همین بالا در دسترس است.',
            },
            {
                selector: '[data-tour="performance-summary"]',
                title: 'جمع‌بندی مدیریتی',
                content: 'خلاصه متنی وضعیت تیم بر اساس داده‌های فیلترشده.',
            },
            {
                selector: '[data-tour="performance-cards"]',
                title: 'کارت‌های عملکرد',
                content: 'فیلتر برترین‌ها و نیازمند توجه. کلیک روی هر کارت به صفحه جزئیات همان کارشناس می‌برد.',
            },
            {
                selector: '[data-tour="performance-charts"]',
                title: 'نمودارهای تیم',
                content: 'روند کیفیت مکالمه را ببینید. روی هر نقطه کلیک کنید تا دلیل افزایش یا کاهش و کارشناسان مؤثر را ببینید.',
            },
            {
                selector: '[data-tour="performance-rankings"]',
                title: 'رتبه‌بندی‌ها',
                content: 'برترین‌ها در امتیاز، لید، پیشرفت و حجم تماس.',
            },
        ],
    },
    'employer.intelligence.index': {
        label: 'تحلیل تماس‌ها',
        steps: [
            {
                selector: '[data-tour="page-header"]',
                title: 'تحلیل تماس‌ها',
                content: 'پایش کیفیت مکالمات، فیلتر پیشرفته و ورود به جزئیات هر تحلیل.',
            },
            {
                selector: '[data-tour="analysis-filters"]',
                title: 'فیلترها',
                content: 'بازه زمانی، کارشناس، وضعیت تماس، جهت و مدت. برای بازه دلخواه تاریخ‌ها را انتخاب و «تایید بازه» را بزنید.',
            },
            {
                selector: '[data-tour="analysis-stats"]',
                title: 'شاخص‌های فیلترشده',
                content: 'تعداد کل تماس‌ها، تعداد تحلیل، میانگین امتیاز، لید، کل لیدها، رضایت و آمار تماس در بازه فعلی.',
            },
            {
                selector: '[data-tour="analysis-charts"]',
                title: 'نمودارهای تحلیل',
                content: 'روند کیفیت، حجم تحلیل، توزیع لید، احساسات و نگرانی‌های پرتکرار.',
            },
            {
                selector: '[data-tour="analysis-list"]',
                title: 'لیست تحلیل‌ها',
                content: 'هر ردیف قابل کلیک است. جستجو، مرتب‌سازی ستون‌ها و فیلتر سریع از همین بخش.',
            },
        ],
    },
    'employer.employees.create': {
        label: 'افزودن کارشناس',
        steps: [
            {
                selector: '[data-tour="employee-form"]',
                title: 'فرم کارشناس',
                content: 'نام، ایمیل، بخش و سمت را وارد کنید. تصویر پروفایل اختیاری است. پس از ذخیره، کارشناس به فضای کار دسترسی پیدا می‌کند.',
            },
        ],
    },
    'employer.employees.edit': {
        label: 'ویرایش کارشناس',
        steps: [
            {
                selector: '[data-tour="employee-form"]',
                title: 'ویرایش اطلاعات',
                content: 'اطلاعات کارشناس، آواتار و وضعیت فعال بودن را به‌روزرسانی کنید.',
            },
        ],
    },
    'employer.customers.index': {
        label: 'مشتریان',
        steps: [
            {
                center: true,
                title: 'پایگاه مشتریان',
                content: 'این بخش شرکت‌ها و اشخاص را جداگانه نشان می‌دهد. در ادامه هر کدام را می‌بینیم.',
            },
            {
                selector: '[data-tour="customers-hub-stats"]',
                title: 'آمار کلی',
                content: 'تعداد شرکت‌ها، اشخاص و کل تماس‌های ثبت‌شده را یکجا ببینید.',
            },
            {
                selector: '[data-tour="customers-hub-companies"]',
                title: 'ورود به شرکت‌ها',
                content: 'شرکت‌های مشتری — هر شرکت می‌تواند چند شخص و آمار تجمیعی داشته باشد.',
            },
            {
                selector: '[data-tour="customers-hub-contacts"]',
                title: 'ورود به اشخاص',
                content: 'افراد حقیقی — پروفایل تماس، امتیاز لید و اتصال به شرکت مربوطه.',
            },
            {
                center: true,
                title: 'لیست شرکت‌ها',
                content: 'حالا بخش شرکت‌ها را باز می‌کنیم تا جستجو و کارت‌های هر شرکت را ببینید.',
                route: 'employer.customers.companies.index',
            },
            {
                selector: '[data-tour="customers-companies-search"]',
                title: 'جستجوی شرکت',
                content: 'جستجو بر اساس نام، صنعت، تلفن یا ایمیل شرکت.',
            },
            {
                selector: '[data-tour="customers-companies-grid"]',
                title: 'کارت‌های شرکت',
                content: 'روی هر کارت کلیک کنید تا اشخاص، آمار تماس و نمودارهای تجمیعی آن شرکت را ببینید.',
            },
            {
                center: true,
                title: 'لیست اشخاص',
                content: 'حالا بخش اشخاص را می‌بینیم — همه افراد، چه به شرکتی متصل باشند چه نباشند.',
                route: 'employer.customers.contacts.index',
            },
            {
                selector: '[data-tour="customers-contacts-search"]',
                title: 'جستجوی شخص',
                content: 'جستجو بر اساس نام، شرکت، شماره تماس یا ایمیل.',
            },
            {
                selector: '[data-tour="customers-contacts-grid"]',
                title: 'کارت‌های شخص',
                content: 'روی هر کارت کلیک کنید تا تاریخچه تماس، امتیاز و بینش‌های هوش مشتری را ببینید.',
            },
        ],
    },
    'employer.customers.companies.index': {
        label: 'شرکت‌ها',
        steps: [
            {
                selector: '[data-tour="page-header"]',
                title: 'لیست شرکت‌ها',
                content: 'شرکت‌های مشتری — با دکمه «شرکت جدید» می‌توانید دستی هم ثبت کنید.',
            },
            {
                selector: '[data-tour="customers-companies-search"]',
                title: 'جستجو',
                content: 'فیلتر سریع بر اساس نام، صنعت، تلفن یا ایمیل.',
            },
            {
                selector: '[data-tour="customers-companies-grid"]',
                title: 'کارت‌های شرکت',
                content: 'تعداد شخص، تماس‌ها و امتیاز تجمیعی هر شرکت روی کارت نمایش داده می‌شود.',
            },
        ],
    },
    'employer.customers.contacts.index': {
        label: 'اشخاص',
        steps: [
            {
                selector: '[data-tour="page-header"]',
                title: 'لیست اشخاص',
                content: 'همه افراد — با یا بدون شرکت. پروفایل از تحلیل تماس‌ها ساخته می‌شود.',
            },
            {
                selector: '[data-tour="customers-contacts-search"]',
                title: 'جستجو',
                content: 'جستجو بر اساس نام، شرکت، شماره یا ایمیل شخص.',
            },
            {
                selector: '[data-tour="customers-contacts-grid"]',
                title: 'کارت‌های شخص',
                content: 'برای جزئیات تماس، امتیاز لید و تاریخچه تعامل روی هر کارت کلیک کنید.',
            },
        ],
    },
    'employer.customers.companies.show': {
        label: 'جزئیات شرکت',
        steps: [
            {
                selector: '[data-tour="company-profile"]',
                title: 'پروفایل شرکت',
                content: 'نام، صنعت، روند مکالمه و سطح لید تجمیعی این شرکت.',
            },
            {
                selector: '[data-tour="company-stats"]',
                title: 'آمار شرکت',
                content: 'تعداد اشخاص، کل تماس‌ها، تماس‌های تحلیل‌شده و میانگین امتیاز.',
            },
            {
                selector: '[data-tour="company-contacts"]',
                title: 'اشخاص شرکت',
                content: 'افراد متصل به این شرکت — برای پروفیل هر شخص روی کارت کلیک کنید.',
            },
            {
                selector: '[data-tour="company-analytics"]',
                title: 'تحلیل تجمیعی',
                content: 'روند امتیاز، توزیع احساسات و نگرانی‌های پرتکرار بر اساس تمام تماس‌های اشخاص.',
            },
        ],
    },
    'employer.customers.show': {
        label: 'جزئیات شخص',
        steps: [
            {
                selector: '[data-tour="customer-profile"]',
                title: 'پروفایل شخص',
                content: 'اطلاعات تماس، شرکت مرتبط، امتیاز کلی و خلاصه هوش مشتری.',
            },
            {
                selector: '[data-tour="customer-timeline"]',
                title: 'تاریخچه تعامل',
                content: 'تماس‌ها و تحلیل‌های مرتبط با این شخص.',
            },
        ],
    },
    'employer.manual-analyses.index': {
        label: 'آپلود دستی',
        steps: [
            {
                selector: '[data-tour="manual-upload-header"]',
                title: 'تحلیل دستی مکالمه',
                content: 'آپلود فایل صوتی برای تحلیل هوش مصنوعی — بدون نیاز به VoIP.',
            },
            {
                selector: '[data-tour="manual-upload-panel"]',
                title: 'آپلود فایل',
                content: 'فایل را بکشید یا انتخاب کنید، کارشناس را مشخص کنید و برای تحلیل ارسال کنید.',
            },
            {
                selector: '[data-tour="manual-history"]',
                title: 'آپلودهای اخیر',
                content: 'تاریخچه آپلودهای تیم با فیلتر وضعیت و کارشناس.',
            },
        ],
    },
    'employer.processing-queue.index': {
        label: 'صف تحلیل',
        steps: [
            {
                selector: '[data-tour="queue-header"]',
                title: 'صف پردازش',
                content: 'پیگیری لحظه‌ای وضعیت تحلیل فایل‌های صوتی آپلودشده.',
            },
            {
                selector: '[data-tour="queue-stats"]',
                title: 'آمار صف',
                content: 'تعداد در صف، در حال پردازش، تکمیل‌شده و ناموفق.',
            },
            {
                selector: '[data-tour="queue-filters"]',
                title: 'فیلتر و جستجو',
                content: 'جستجو بر اساس نام فایل یا فیلتر وضعیت.',
            },
            {
                selector: '[data-tour="queue-table"]',
                title: 'لیست کارها',
                content: 'جزئیات هر کار پردازش و لینک به نتیجه تحلیل.',
            },
        ],
    },
    'employer.crm.index': {
        label: 'CRM',
        steps: [
            {
                selector: '[data-tour="crm-header"]',
                title: 'یکپارچه‌سازی CRM',
                content: 'اتصال CRM برای شناسایی تماس‌گیرنده و غنی‌سازی هوش مشتری.',
            },
            {
                selector: '[data-tour="crm-connections"]',
                title: 'اتصالات',
                content: 'وضعیت اتصال هر ارائه‌دهنده CRM و فعال بودن جستجوی شخص.',
            },
            {
                selector: '[data-tour="crm-settings"]',
                title: 'تنظیمات معامله',
                content: 'کاریز، مرحله کاریز و مالک معامله (اختیاری) را برای ایجاد معامله در دیدار تنظیم کنید.',
            },
        ],
    },
    'employer.extensions.index': {
        label: 'داخلی‌ها',
        steps: [
            {
                selector: '[data-tour="page-header"]',
                title: 'داخلی‌ها',
                content: 'اینجا شماره داخلی را خودتان ثبت می‌کنید و به کارشناس وصل می‌کنید. سیستم دیگر داخلی را از تماس‌ها تشخیص نمی‌دهد.',
            },
            {
                selector: '[data-tour="extensions-add-button"]',
                title: 'افزودن داخلی',
                content: 'روی این دکمه بزنید تا فرم ثبت داخلی باز شود. شماره داخلی، خط تلفن و کارشناس را انتخاب کنید.',
            },
            {
                selector: '[data-tour="extensions-list"]',
                title: 'فهرست داخلی‌ها',
                content: 'داخلی‌های ثبت‌شده را ببینید، کارشناس را عوض کنید یا در صورت نیاز حذف کنید.',
            },
        ],
    },
    'employer.organization.profile': {
        label: 'پروفایل سازمان',
        steps: [
            {
                selector: '[data-tour="page-header"]',
                title: 'پروفایل سازمان',
                content: 'نام سازمان، ارائه‌دهنده ویپ، اتصال پیش‌فرض و آدرس وب‌هوک را اینجا ببینید. این اطلاعات قابل تغییر نیستند.',
            },
            {
                selector: '[data-tour="organization-details"]',
                title: 'اطلاعات سازمان',
                content: 'جزئیات ثبت‌شده سازمان و اتصال ویپ فقط برای مشاهده است.',
            },
            {
                selector: '[data-tour="organization-call-filters"]',
                title: 'فیلتر تماس‌های ورودی',
                content: 'مشخص کنید تماس بین کارشناسان داخلی، یا تماسی که کارشناس ندارد، تحلیل شود یا نه.',
            },
            {
                selector: '[data-tour="organization-holidays"]',
                title: 'تعطیلات شرکت',
                content: 'روزهای تعطیل هفته را مشخص کنید تا تماس‌های آن روزها در آمار عملکرد نیاید.',
            },
        ],
    },
    'employer.voip.index': {
        label: 'خطوط تلفنی',
        steps: [
            {
                selector: '[data-tour="voip-header"]',
                title: 'VoIP',
                content: 'اتصال سیستم تلفنی برای دریافت تماس‌های ورودی در فضای کارشناس.',
            },
            {
                selector: '[data-tour="voip-guide"]',
                title: 'راهنمای وب‌هوک',
                content: 'آدرس وب‌هوک و پارامترهای لازم برای ارسال رویداد تماس.',
            },
            {
                selector: '[data-tour="voip-stats"]',
                title: 'آمار تماس',
                content: 'تماس‌های امروز، ماه جاری و اتصالات فعال.',
            },
            {
                selector: '[data-tour="voip-connections"]',
                title: 'اتصالات VoIP',
                content: 'جزئیات هر خط و آدرس وب‌هوک اختصاصی.',
            },
        ],
    },
};

const navSteps = [
    ['employer.dashboard', 'داشبورد', 'نقطه شروع مدیر: نمای کلی تیم و عملکرد کارشناسان.'],
    ['employer.intelligence.performance', 'عملکرد کارشناسان', 'رتبه‌بندی، مقایسه و ارزیابی مهارت تیم تماس.'],
    ['employer.intelligence.index', 'تحلیل تماس‌ها', 'فهرست تمام تحلیل‌ها با فیلتر و جزئیات هر مکالمه.'],
    ['employer.extensions.index', 'داخلی‌ها', 'شماره داخلی را دستی ثبت کنید و به کارشناس وصل کنید تا تماس‌هایش به او نسبت داده شود.'],
    ['employer.customers.index', 'مشتریان', 'شرکت‌ها و اشخاص — پروفایل خودکار از تحلیل تماس‌ها، با آمار تجمیعی برای هر شرکت.'],
    ['employer.manual-analyses.index', 'آپلود دستی', 'تحلیل فایل صوتی بدون VoIP.'],
    ['employer.processing-queue.index', 'صف تحلیل', 'پیگیری وضعیت پردازش فایل‌های در صف.'],
    ['employer.crm.index', 'CRM', 'اتصال سیستم ارتباط با مشتری.'],
    ['employer.voip.index', 'خطوط تلفنی', 'اتصال VoIP و وب‌هوک تماس.'],
    ['employer.organization.profile', 'پروفایل سازمان', 'اطلاعات سازمان، اتصال ویپ، فیلتر تماس‌های ورودی و تعطیلات شرکت.'],
];

/** @returns {TourStep[]} */
export function buildFullEmployerTour() {
    /** @type {TourStep[]} */
    const steps = [
        {
            center: true,
            title: 'به پنل کارفرما خوش آمدید',
            content: 'این راهنمای تعاملی همه منوها و بخش‌های مهم را مرحله‌به‌مرحله معرفی می‌کند. می‌توانید هر زمان رد کنید یا بعداً از دکمه راهنما ادامه دهید.',
        },
        {
            selector: '[data-tour="sidebar"]',
            title: 'منوی اصلی',
            content: 'از این نوار برای جابه‌جایی بین بخش‌های برنامه استفاده کنید. در ادامه هر منو را جداگانه می‌بینیم.',
        },
        {
            selector: '[data-tour="topbar-theme"]',
            title: 'حالت تاریک/روشن',
            content: 'ظاهر برنامه را مطابق ترجیح خود تغییر دهید.',
        },
    ];

    navSteps.forEach(([route, title, content]) => {
        if (! window.__employerOnboarding?.routes?.[route]) {
            return;
        }

        steps.push({
            selector: `[data-tour-nav="${route}"]`,
            title,
            content,
            route,
        });
    });

    steps.push({
        fab: true,
        title: 'دکمه راهنما',
        content: 'هر زمان بخواهید آموزش همان صفحه را ببینید، روی این دکمه بزنید. راهنمای جزئیات هر بخش همیشه از اینجا در دسترس است.',
        placement: 'top',
        align: 'start',
    });

    steps.push({
        center: true,
        title: 'پایان راهنمای کلی',
        content: 'آشنایی با پنل تمام شد. برای شروع کار، از منوی کناری به بخش مورد نظر بروید یا روی «راهنما» بزنید تا آموزش همان صفحه را ببینید.',
    });

    return steps;
}

export const FULL_TOUR_ID = 'employer-full';

/** @type {Array<{ pattern: RegExp, route: string }>} */
export const employerRouteMatchers = [
    { pattern: /^\/app\/?$/, route: 'employer.dashboard' },
    { pattern: /^\/app\/employees\/create\/?$/, route: 'employer.employees.create' },
    { pattern: /^\/app\/employees\/\d+\/edit\/?$/, route: 'employer.employees.edit' },
    { pattern: /^\/app\/intelligence\/performance\/\d+\/?$/, route: 'employer.intelligence.performance.show' },
    { pattern: /^\/app\/intelligence\/performance\/?$/, route: 'employer.intelligence.performance' },
    { pattern: /^\/app\/intelligence\/\d+\/?$/, route: 'employer.intelligence.show' },
    { pattern: /^\/app\/intelligence\/?$/, route: 'employer.intelligence.index' },
    { pattern: /^\/app\/manual-analyses\/\d+\/?$/, route: 'employer.manual-analyses.show' },
    { pattern: /^\/app\/manual-analyses\/?$/, route: 'employer.manual-analyses.index' },
    { pattern: /^\/app\/processing-queue\/\d+\/?$/, route: 'employer.processing-queue.show' },
    { pattern: /^\/app\/processing-queue\/?$/, route: 'employer.processing-queue.index' },
    { pattern: /^\/app\/customers\/companies\/?$/, route: 'employer.customers.companies.index' },
    { pattern: /^\/app\/customers\/contacts\/?$/, route: 'employer.customers.contacts.index' },
    { pattern: /^\/app\/customers\/companies\/\d+\/?$/, route: 'employer.customers.companies.show' },
    { pattern: /^\/app\/customers\/\d+\/edit\/?$/, route: 'employer.customers.edit' },
    { pattern: /^\/app\/customers\/\d+\/?$/, route: 'employer.customers.show' },
    { pattern: /^\/app\/customers\/?$/, route: 'employer.customers.index' },
    { pattern: /^\/app\/crm\/?$/, route: 'employer.crm.index' },
    { pattern: /^\/app\/extensions\/?$/, route: 'employer.extensions.index' },
    { pattern: /^\/app\/unmatched-extensions\/?$/, route: 'employer.extensions.index' },
    { pattern: /^\/app\/voip\/?$/, route: 'employer.voip.index' },
    { pattern: /^\/app\/organization\/?$/, route: 'employer.organization.profile' },
];

export function resolveEmployerRoute(pathname) {
    const path = (pathname || window.location.pathname).replace(/\/+$/, '') || '/app';

    for (const { pattern, route } of employerRouteMatchers) {
        if (pattern.test(path)) {
            return route;
        }
    }

    return window.__employerOnboarding?.currentRoute ?? null;
}

export function tourForRoute(route) {
    if (! route) {
        return null;
    }

    if (employerPageTours[route]) {
        return employerPageTours[route];
    }

    if (route === 'employer.intelligence.performance.show') {
        return employerPageTours['employer.intelligence.performance'];
    }

    if (route === 'employer.intelligence.show') {
        return {
            label: 'جزئیات تحلیل',
            steps: [
                {
                    selector: '[data-tour="analysis-detail"]',
                    title: 'جزئیات تحلیل تماس',
                    content: 'امتیاز، خلاصه، نگرانی‌ها، احساسات و پیشنهادهای بهبود این مکالمه.',
                },
            ],
        };
    }

    if (route === 'employer.manual-analyses.show' || route === 'employer.processing-queue.show') {
        return {
            label: 'جزئیات',
            steps: [
                {
                    center: true,
                    title: 'صفحه جزئیات',
                    content: 'وضعیت پردازش، فایل صوتی و نتیجه تحلیل را در این صفحه ببینید.',
                },
            ],
        };
    }

    return null;
}
