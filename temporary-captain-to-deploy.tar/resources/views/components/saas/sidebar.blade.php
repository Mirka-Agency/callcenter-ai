@php
    $user = auth()->user();
    $sidebarLabels = [];

    foreach ($navItems as $item) {
        $sidebarLabels[] = [
            'label' => $item['label'],
            'nested' => false,
            'chevron' => ! empty($item['children']),
        ];

        foreach ($item['children'] ?? [] as $child) {
            $sidebarLabels[] = [
                'label' => $child['label'],
                'nested' => true,
                'chevron' => false,
            ];
        }
    }

    $sidebarLabels[] = [
        'label' => ($impersonationContext ?? null) ? 'بازگشت به مدیریت' : 'خروج از حساب',
        'nested' => false,
        'chevron' => false,
    ];
@endphp

<aside
    class="saas-sidebar"
    :class="{ 'saas-sidebar--open': $store.layout.sidebarOpen }"
    data-tour="sidebar"
>
    <div class="saas-sidebar-sizer" aria-hidden="true">
        <div class="px-3 lg:px-4">
            @foreach ($sidebarLabels as $entry)
                <div @class(['ms-5 border-s border-transparent ps-2' => $entry['nested']])>
                    <span class="saas-nav-item">
                        <span class="saas-nav-item-icon"></span>
                        <span class="saas-nav-label">{{ $entry['label'] }}</span>
                        @if ($entry['chevron'])
                            <span class="ms-auto h-4 w-4 shrink-0"></span>
                        @endif
                    </span>
                </div>
            @endforeach
        </div>
    </div>

    <div class="saas-sidebar-body">
    <div class="saas-sidebar-header">
        <div class="min-w-0 flex-1">
            <p class="truncate text-sm font-bold text-zinc-900 dark:text-white">{{ config('app.name') }}</p>
            <p class="mt-0.5 text-xs text-zinc-500">{{ $portal === 'employer' ? 'پنل کارفرما' : 'فضای کار کارشناس' }}</p>
            @if ($impersonationContext ?? null)
                <span class="impersonation-sidebar-badge mt-1">ورود به‌جای کاربر</span>
            @endif
        </div>

        <button
            type="button"
            class="saas-sidebar-close"
            @click="$store.layout.closeSidebar()"
            aria-label="بستن منو"
        >
            <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
    </div>

    @if ($user)
        <a
            href="{{ route(($portal ?? 'employer').'.profile.edit') }}"
            class="saas-sidebar-user"
            wire:navigate
            @click="$store.layout.closeSidebar()"
        >
            <x-saas.avatar :user="$user" size="sm" ring person />
            <div class="min-w-0 flex-1">
                <p class="truncate text-sm font-semibold text-zinc-900 dark:text-white">{{ $user->name }}</p>
                <p class="truncate text-xs text-zinc-500">{{ $user->email }}</p>
            </div>
            <svg class="h-4 w-4 shrink-0 text-zinc-400 rtl:rotate-180" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
            </svg>
        </a>
    @endif

    <nav class="flex-1 space-y-1 overflow-y-auto overscroll-contain px-3 py-3 lg:p-4" aria-label="منوی اصلی">
        @foreach ($navItems as $item)
            @php
                $navIsCurrent = function (array $entry): bool {
                    $patterns = $entry['matches'] ?? array_filter([
                        ($entry['route'] ?? null) ? $entry['route'].'*' : null,
                        $entry['route'] ?? null,
                    ]);

                    foreach ($patterns as $pattern) {
                        if (request()->routeIs($pattern)) {
                            return true;
                        }
                    }

                    return false;
                };
                $isActive = $navIsCurrent($item);
                $childActive = collect($item['children'] ?? [])->contains($navIsCurrent);
            @endphp
            @if (! empty($item['children']))
                <div
                    class="space-y-1"
                    x-data="{
                        open: false,
                        forceOpen: @js($isActive || $childActive),
                        storageKey: @js('avayar-nav-'.($item['key'] ?? $item['route'] ?? $item['label'])),
                        init() {
                            if (this.forceOpen) {
                                this.open = true;
                                return;
                            }
                            const stored = localStorage.getItem(this.storageKey);
                            this.open = stored === null ? true : stored === '1';
                        },
                        toggle() {
                            this.open = ! this.open;
                            localStorage.setItem(this.storageKey, this.open ? '1' : '0');
                        },
                    }"
                >
                    <button
                        type="button"
                        class="saas-nav-item w-full"
                        @click="toggle()"
                        :aria-expanded="open"
                        aria-controls="nav-group-{{ $item['key'] ?? $item['route'] }}"
                        aria-label="باز و بسته کردن {{ $item['label'] }}"
                    >
                        <span class="saas-nav-item-icon">
                            <x-saas.icon :name="$item['icon']" class="h-4 w-4" />
                        </span>
                        <span class="saas-nav-label">{{ $item['label'] }}</span>
                        <svg class="ms-auto h-4 w-4 shrink-0 transition" :class="open ? 'rotate-180' : ''" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                        </svg>
                    </button>
                    <div
                        id="nav-group-{{ $item['key'] ?? $item['route'] }}"
                        x-show="open"
                        x-cloak
                        class="ms-5 space-y-1 border-s border-zinc-200 ps-2 dark:border-zinc-800"
                    >
                        @foreach ($item['children'] as $child)
                            @php
                                $isChildActive = $navIsCurrent($child);
                            @endphp
                            <a
                                href="{{ route($child['route']) }}"
                                data-tour-nav="{{ $child['route'] }}"
                                wire:navigate
                                @class([
                                    'saas-nav-item',
                                    'saas-nav-item-active' => $isChildActive,
                                ])
                                @click="$store.layout.closeSidebar()"
                            >
                                <span class="saas-nav-item-icon">
                                    <x-saas.icon :name="$child['icon']" class="h-4 w-4" />
                                </span>
                                <span class="saas-nav-label">{{ $child['label'] }}</span>
                            </a>
                        @endforeach
                    </div>
                </div>
            @else
                <a
                    href="{{ route($item['route']) }}"
                    data-tour-nav="{{ $item['route'] }}"
                    wire:navigate
                    @class([
                        'saas-nav-item',
                        'saas-nav-item-active' => $isActive,
                    ])
                    @click="$store.layout.closeSidebar()"
                >
                    <span class="saas-nav-item-icon">
                        <x-saas.icon :name="$item['icon']" class="h-4 w-4" />
                    </span>
                    <span class="saas-nav-label">{{ $item['label'] }}</span>
                </a>
            @endif
        @endforeach
    </nav>

    <div class="shrink-0 border-t border-zinc-200/80 p-3 dark:border-zinc-800 lg:p-4">
        @if ($impersonationContext ?? null)
            <form method="POST" action="{{ route('impersonation.stop') }}" class="mb-2">
                @csrf
                <button type="submit" class="saas-nav-item w-full text-start text-amber-700 dark:text-amber-300">
                    <span class="saas-nav-item-icon">
                        <x-saas.icon name="home" class="h-4 w-4" />
                    </span>
                    <span class="saas-nav-label">بازگشت به مدیریت</span>
                </button>
            </form>
        @else
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="saas-nav-item w-full text-start text-red-600 hover:bg-red-50 hover:text-red-700 dark:text-red-400 dark:hover:bg-red-950/30 dark:hover:text-red-300">
                    <span class="saas-nav-item-icon">
                        <x-saas.icon name="logout" class="h-4 w-4" />
                    </span>
                    <span class="saas-nav-label">خروج از حساب</span>
                </button>
            </form>
        @endif
    </div>
    </div>
</aside>

<div
    class="saas-sidebar-overlay"
    :class="{ 'is-visible': $store.layout.sidebarOpen }"
    :aria-hidden="! $store.layout.sidebarOpen"
    @click="$store.layout.closeSidebar()"
></div>
