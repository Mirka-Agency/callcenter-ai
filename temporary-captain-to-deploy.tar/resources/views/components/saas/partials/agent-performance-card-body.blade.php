@php
    use App\Support\AgentPerformancePresenter;

    $subtitle = collect([$agent['position'] ?? null, $agent['department'] ?? null])->filter()->implode(' · ')
        ?: 'کارشناس تماس';
@endphp

<div class="flex h-full flex-col gap-4">
    <div class="flex items-start gap-4">
        <x-saas.avatar
            :name="$agent['name']"
            :gender="$agent['gender'] ?? null"
            agent
            size="lg"
            ring
            class="shrink-0"
        />

        <div class="min-w-0 flex-1">
            @if ($showRank && ($agent['rank'] ?? null))
                <p class="text-xs font-medium text-zinc-400">رتبه #{{ $agent['rank'] }}</p>
            @endif
            <h3 class="mt-0.5 text-lg font-bold leading-snug text-zinc-900 dark:text-white">
                {{ $agent['name'] }}
            </h3>
            <p class="mt-0.5 text-sm text-zinc-500">{{ $subtitle }}</p>

            <div class="mt-2.5 flex flex-wrap items-center gap-1.5">
                @if ($tier != 'normal')
                    <span @class([
                        'rounded-md px-2.5 py-0.5 text-[11px] font-semibold',
                        'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300' => $tier === 'top',
                        'bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300' => $tier === 'attention',
                    ])>{{ AgentPerformancePresenter::tierLabel($tier) }}</span>
                @endif
                <span @class(['rounded-md px-2.5 py-0.5 text-xs font-medium', AgentPerformancePresenter::trendBadgeClass($agent['trend'] ?? null)])>
                    {{ AgentPerformancePresenter::trendIcon($agent['trend'] ?? null) }}
                    {{ AgentPerformancePresenter::trendLabel($agent['trend'] ?? null) }}
                </span>
            </div>
        </div>

        <x-saas.score-ring :score="$agent['average_score']" size="sm" class="hidden shrink-0 sm:flex" />
    </div>

    <x-saas.score-ring :score="$agent['average_score']" size="sm" class="flex justify-center sm:hidden" />

    <dl class="grid grid-cols-2 gap-x-4 gap-y-3 border-t border-zinc-100 pt-4 dark:border-zinc-800 sm:grid-cols-4">
        <div>
            <dt class="text-[11px] text-zinc-500">تحلیل‌شده</dt>
            <dd class="text-sm font-semibold tabular-nums">{{ $agent['total_analyzed'] ?? 0 }}</dd>
        </div>
        <div>
            <dt class="text-[11px] text-zinc-500">نرخ پاسخ</dt>
            <dd class="text-sm font-semibold tabular-nums">{{ isset($agent['answer_rate']) ? $agent['answer_rate'].'%' : '—' }}</dd>
        </div>
        <div>
            <dt class="text-[11px] text-zinc-500">امتیاز لید</dt>
            <dd @class(['text-sm font-semibold tabular-nums', AgentPerformancePresenter::scoreTextClass($agent['average_lead_score'] ?? null)])>
                {{ $agent['average_lead_score'] ?: '—' }}
            </dd>
        </div>
        <div>
            <dt class="text-[11px] text-zinc-500">رضایت مشتری</dt>
            <dd class="text-sm font-semibold tabular-nums">{{ $agent['average_sentiment'] ?: '—' }}</dd>
        </div>
    </dl>

    @if (filled($agent['average_duration_label'] ?? null))
        <p class="text-xs text-zinc-500">
            {{ (int) ($agent['total_analyzed'] ?? 0) }} تماس بررسی شده و میانگین مدت مکالمه <span class="font-medium text-zinc-700 dark:text-zinc-300">{{ $agent['average_duration_label'] }}</span> بوده.
        </p>
    @endif

    <div class="mt-auto grid gap-2 sm:grid-cols-2">
        <div class="rounded-md border border-emerald-200/70 bg-emerald-50/50 px-3 py-2 dark:border-emerald-900/40 dark:bg-emerald-950/20">
            <p class="text-[11px] font-medium text-emerald-700 dark:text-emerald-300">نقطه قوت</p>
            <p class="mt-0.5 text-sm leading-6 text-zinc-800 dark:text-zinc-100">{{ filled($agent['top_strength'] ?? null) ? $agent['top_strength'] : 'ثبت نشده' }}</p>
        </div>
        <div class="rounded-md border border-amber-200/70 bg-amber-50/50 px-3 py-2 dark:border-amber-900/40 dark:bg-amber-950/20">
            <p class="text-[11px] font-medium text-amber-800 dark:text-amber-300">نقطه ضعف</p>
            <p class="mt-0.5 text-sm leading-6 text-zinc-800 dark:text-zinc-100">{{ filled($agent['top_weakness'] ?? null) ? $agent['top_weakness'] : 'ثبت نشده' }}</p>
        </div>
    </div>
</div>
