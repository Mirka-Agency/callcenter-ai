<!DOCTYPE html>
<html lang="fa" dir="rtl" x-data x-init="$nextTick(() => { $store.layout?.closeSidebar?.(); })" x-bind:class="$store.theme.dark ? 'dark' : ''">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? config('app.name') }}</title>
    @if (($portal ?? '') === 'employer')
        @php
            $onboardingRoutes = \App\Support\Onboarding\EmployerOnboarding::routeUrls();
        @endphp
        <script>
            window.__employerOnboarding = {
                currentRoute: @json(\Illuminate\Support\Facades\Route::currentRouteName()),
                routes: @json($onboardingRoutes),
            };
        </script>
    @endif
    @if (($portal ?? '') === 'employee')
        @php
            $employeeOnboardingRoutes = \App\Support\Onboarding\EmployeeOnboarding::routeUrls();
        @endphp
        <script>
            window.__employeeOnboarding = {
                currentRoute: @json(\Illuminate\Support\Facades\Route::currentRouteName()),
                routes: @json($employeeOnboardingRoutes),
            };
        </script>
    @endif
    <link rel="stylesheet" href="{{ asset('css/vazirmatn.css') }}">
    @vite(['resources/css/saas.css', 'resources/js/saas.js'])
    @livewireStyles
    <script>
        (function () {
            const dark = localStorage.getItem('theme') === 'dark';
            document.documentElement.classList.toggle('dark', dark);
        })();
    </script>
</head>
<body
    class="saas-shell font-sans"
    @keydown.escape.window="$store.layout.closeSidebar()"
>
    <script>
        document.documentElement.classList.remove('overflow-hidden');
        document.body.classList.remove('overflow-hidden', 'employer-onboarding-open', 'employee-onboarding-open');
    </script>
    <div id="saas-request-progress" class="saas-request-progress" aria-hidden="true">
        <div class="saas-request-progress__bar"></div>
    </div>

    @include('components.saas.impersonation-banner')

    <div class="saas-frame">
        @include('components.saas.sidebar', ['portal' => $portal ?? 'employer', 'navItems' => $navItems ?? []])

        <div class="saas-main">
            @include('components.saas.topbar', ['portal' => $portal ?? 'employer', 'navItems' => $navItems ?? []])

            <main class="saas-content">
                {{ $slot }}
            </main>
        </div>
    </div>

    @if (($portal ?? '') === 'employee' && auth()->check())
        <livewire:employee.incoming-call-center />
    @endif

    @auth
        @include('components.saas.toast-stack')
    @endauth

    @if (in_array($portal ?? '', ['employer', 'employee'], true))
        <x-saas.onboarding-tour :portal="$portal" />
    @endif

    <script>
        window.dashboardTableSort = function dashboardTableSort(config) {
            config = config || {};

            return {
                column: config.column || 'date',
                dir: config.dir || 'desc',
                allowed: config.allowed || [],
                defaultDir: config.defaultDir || 'desc',
                isActive(column) {
                    return this.column === column;
                },
                ariaSort(column) {
                    if (this.column !== column) {
                        return 'none';
                    }

                    return this.dir === 'asc' ? 'ascending' : 'descending';
                },
                sortIconClass(column) {
                    return {
                        'is-active': this.column === column,
                        'is-asc': this.column === column && this.dir === 'asc',
                        'is-desc': this.column === column && this.dir === 'desc',
                    };
                },
                sortBy(column) {
                    if (! this.allowed.includes(column)) {
                        return;
                    }

                    if (this.column === column) {
                        this.dir = this.dir === 'asc' ? 'desc' : 'asc';
                    } else {
                        this.column = column;
                        this.dir = this.defaultDir;
                    }

                    this.apply();
                },
                apply() {
                    const table = this.$refs.table || this.$root.querySelector('table');
                    const list = this.$refs.list;
                    const container = table || list;

                    if (! container) {
                        return;
                    }

                    const attr = 'data-sort-' + this.column.replaceAll('_', '-');
                    const multiplier = this.dir === 'asc' ? 1 : -1;
                    const selector = table ? ':scope > tbody[data-sort-row]' : ':scope > [data-sort-row]';

                    Array.from(container.querySelectorAll(selector))
                        .sort(function (left, right) {
                            const a = Number(left.getAttribute(attr) || Number.NEGATIVE_INFINITY);
                            const b = Number(right.getAttribute(attr) || Number.NEGATIVE_INFINITY);

                            if (a === b) {
                                return 0;
                            }

                            return a < b ? -1 * multiplier : 1 * multiplier;
                        })
                        .forEach(function (row) {
                            container.appendChild(row);
                        });
                },
            };
        };
    </script>
    @livewireScripts
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.store('theme', {
                dark: document.documentElement.classList.contains('dark'),
                toggle() {
                    this.dark = !this.dark;
                    localStorage.setItem('theme', this.dark ? 'dark' : 'light');
                    document.documentElement.classList.toggle('dark', this.dark);
                },
            });
        });
    </script>
</body>
</html>
