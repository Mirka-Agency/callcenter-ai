@php
    $kpis = $dashboard['kpis'];
    $deltas = $dashboard['kpis_delta'];
    $qualityTrend = $dashboard['quality_trend'];

    $qualityChart = [
        'labels' => collect($qualityTrend)->pluck('label')->all(),
        'tooltipTitles' => collect($qualityTrend)->pluck('tooltip_label')->all(),
        'tooltipBodies' => collect($qualityTrend)->pluck('tooltip_body')->all(),
        'datasets' => [[
            'label' => 'امتیاز کیفیت مکالمه',
            'data' => collect($qualityTrend)->pluck('avg_score')->all(),
            'borderColor' => 'rgb(16, 185, 129)',
            'backgroundColor' => 'rgba(16, 185, 129, 0.12)',
            'pointRadius' => 0,
            'pointHoverRadius' => 6,
            'pointHitRadius' => 20,
            'fill' => true,
            'tension' => 0.35,
            'spanGaps' => true,
        ]],
    ];

    $profileUrl = fn (array $agent) => route('employer.intelligence.performance.show', $agent['id']).'?preset='.$datePreset.'&from='.$customFrom.'&to='.$customTo;

    $filterActionTargets = 'applyCustomDateRange,setDatePreset,closeCustomDateRangePanel,clearDateFilter,clearFilters,clearEmployeeFilter,selectTeamWeakness,clearTeamWeakness';
@endphp

<div class="saas-page space-y-6">
    <x-saas.page-header
        data-tour="page-header"
        title="عملکرد کارشناسان"
        description="مقایسه، رتبه‌بندی و شناسایی فرصت‌های ارزیابی مهارت تیم تماس."
    >
        <x-slot:actions>
            <a href="{{ route('employer.employees.create') }}" class="saas-btn-primary">@lang('ui.cta.add_employee')</a>
            <x-saas.export-actions route-name="employer.intelligence.performance.export" :formats="['pdf']" />
        </x-slot:actions>
    </x-saas.page-header>

    @include('livewire.employer.intelligence.partials.performance-filters')

    <div class="relative space-y-6">
        <x-saas.filter-loading-overlay scoped :target="$filterActionTargets" />

    <div class="grid items-stretch gap-4 md:grid-cols-2">
        <section class="saas-hero saas-hero--accent h-full" data-tour="performance-summary">
            <p class="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">جمع‌بندی مدیریتی</p>
            <p class="mt-3 text-base leading-8 text-zinc-700 dark:text-zinc-200">{{ $dashboard['executive_summary'] }}</p>
        </section>

        <div class="grid h-full grid-cols-2 grid-rows-2 gap-4">
            <x-saas.stat-card label="کارشناسان فعال" :value="$kpis['active_employees']" icon-tone="violet">
                <x-slot:icon><x-saas.icon name="users" /></x-slot:icon>
            </x-saas.stat-card>
            <x-saas.stat-card label="تماس‌های تحلیل‌شده" :value="$kpis['total_analyzed']" :trend="$deltas['total_analyzed']" icon-tone="sky">
                <x-slot:icon><x-saas.icon name="phone" /></x-slot:icon>
            </x-saas.stat-card>
            <x-saas.stat-card label="میانگین امتیاز مکالمه" :value="$kpis['average_quality_score'] ?: '—'" :trend="$deltas['average_quality_score']" icon-tone="green">
                <x-slot:icon><x-saas.icon name="chart" /></x-slot:icon>
            </x-saas.stat-card>
            <x-saas.stat-card label="میانگین رضایت مشتری" :value="$kpis['average_sentiment'] ? $kpis['average_sentiment'].'%' : '—'" :trend="$deltas['average_sentiment']" icon-tone="amber">
                <x-slot:icon><x-saas.icon name="sparkles" /></x-slot:icon>
            </x-saas.stat-card>
        </div>
    </div>

    @include('livewire.employer.partials.attention-agents', [
        'attentionEmployees' => $dashboard['attention_employees'],
        'agentProfileUrl' => $profileUrl,
    ])

    @include('livewire.employer.partials.agent-performance-cards', [
        'title' => 'کارت‌های عملکرد',
        'subtitle' => 'برای مشاهده جزئیات، روی هر کارشناس کلیک کنید.',
        'agentCardFeed' => $agentCardFeed,
        'agentCardFilter' => $agentCardFilter,
        'agentProfileUrl' => $profileUrl,
        'emptyTitle' => __('ui.empty.no_activity.title'),
        'emptyDescription' => __('ui.empty.no_activity.description'),
        'sectionTour' => 'performance-cards',
    ])

    <div @class([
        'grid items-stretch gap-6',
        'lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]' => ! empty($dashboard['team_weaknesses']),
    ]) data-tour="performance-charts">
        <div
            class="saas-card h-full min-w-0"
            data-quality-trend-card
            wire:key="perf-quality-trend-{{ $datePreset }}-{{ $customFrom }}-{{ $customTo }}-{{ implode('-', $selectedEmployeeIds) }}"
            x-data="qualityTrendCard({{ \Illuminate\Support\Js::from($qualityTrendInsights ?? []) }}, {{ \Illuminate\Support\Js::from($agentProfileBase ?? '') }}, {{ \Illuminate\Support\Js::from($agentProfileQuery ?? '') }})"
            @quality-trend-select="select($event.detail.period)"
        >
            <h2 class="text-lg font-semibold">روند کیفیت مکالمه</h2>
            <p class="mt-1 text-sm text-zinc-500">میانگین امتیاز مکالمه در بازه انتخاب‌شده. برای دیدن دلیل تغییر، روی یک نقطه کلیک کنید.</p>
            <div data-drilldown-selected="{{ $selectedQualityTrendPeriod ?? '' }}" :data-drilldown-selected="selected">
                <div class="relative mt-4 h-64" wire:ignore>
                    <canvas
                        id="perf-quality-trend"
                        class="cursor-pointer"
                        draggable="false"
                        data-report-chart
                        data-type="line"
                        data-config='@json($qualityChart)'
                        data-drilldown="period"
                        data-drilldown-values='@json(collect($qualityTrend)->pluck('period')->all())'
                    ></canvas>
                </div>
            </div>
            @include('livewire.employer.partials.quality-trend-insight-client')
            @if (! empty($qualityTrendInsight))
                <div x-show="!insight">
                    @include('livewire.employer.partials.quality-trend-insight', [
                        'qualityTrendInsight' => $qualityTrendInsight,
                        'agentProfileQuery' => $agentProfileQuery ?? '',
                    ])
                </div>
            @endif
        </div>

        @include('livewire.employer.partials.team-weaknesses-card', [
            'teamWeaknesses' => $dashboard['team_weaknesses'],
            'selectedTeamWeakness' => $selectedTeamWeakness,
            'teamWeaknessCalls' => $teamWeaknessCalls,
            'variant' => 'table',
            'cardClass' => 'h-full',
        ])
    </div>

    @php
        $rankingMeta = [
            'best_quality' => [
                'title' => 'بالاترین امتیاز',
                'subtitle' => 'کیفیت مکالمه',
                'accent' => 'indigo',
                'icon' => 'M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.8 6.5 20l1-6.2L3 9.4l6.2-.9L12 3z',
            ],
            'most_improved' => [
                'title' => 'بیشترین پیشرفت',
                'subtitle' => 'رشد دوره اخیر',
                'accent' => 'amber',
                'icon' => 'M4 14l4-4 3 3 5-6 4 4M20 8V4h-4',
            ],
            'most_calls' => [
                'title' => 'بیشترین تماس',
                'subtitle' => 'حجم فعالیت',
                'accent' => 'sky',
                'icon' => 'M5 7a2 2 0 0 1 2-2h2l2 4-1.5 1.5a12 12 0 0 0 5 5L16 14l4 2v2a2 2 0 0 1-2 2h-1C10.4 20 4 13.6 4 6V5z',
            ],
        ];
    @endphp

    <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" data-tour="performance-rankings">
        @foreach ($rankingMeta as $key => $meta)
            @php
                $accentClasses = match ($meta['accent']) {
                    'amber' => 'from-amber-500/10 to-amber-100/30 border-amber-200/70 dark:from-amber-500/15 dark:to-amber-950/20 dark:border-amber-500/20',
                    'sky' => 'from-sky-500/10 to-sky-100/30 border-sky-200/70 dark:from-sky-500/15 dark:to-sky-950/20 dark:border-sky-500/20',
                    default => 'from-indigo-500/10 to-indigo-100/30 border-indigo-200/70 dark:from-indigo-500/15 dark:to-indigo-950/20 dark:border-indigo-500/20',
                };
            @endphp
            <div @class([
                'saas-widget border bg-gradient-to-b',
                $accentClasses,
            ])>
                <div class="flex items-start gap-3">
                    <span class="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/80 text-zinc-700 shadow-sm dark:bg-zinc-900/70 dark:text-zinc-200">
                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="{{ $meta['icon'] }}" />
                        </svg>
                    </span>
                    <div>
                        <h3 class="text-sm font-semibold text-zinc-800 dark:text-zinc-100">{{ $meta['title'] }}</h3>
                        <p class="mt-0.5 text-[11px] text-zinc-500">{{ $meta['subtitle'] }}</p>
                    </div>
                </div>

                <ol class="mt-3 space-y-1.5">
                    @forelse (array_slice($dashboard['rankings'][$key] ?? [], 0, 3) as $i => $row)
                        <li>
                            @php
                                $metricValue = match ($key) {
                                    'most_calls' => $row['total_calls'],
                                    'most_improved' => (($row['improvement_percent'] ?? 0) > 0 ? '+' : '').($row['improvement_percent'] ?? 0).'%',
                                    default => $row['average_score'] ?? '—',
                                };
                            @endphp
                            <x-saas.agent-rank-row
                                :row="$row"
                                :rank="$i + 1"
                                :href="$profileUrl($row)"
                                :value="$metricValue"
                            />
                        </li>
                    @empty
                        <li class="rounded-lg border border-dashed border-zinc-200 px-3 py-4 text-center text-xs text-zinc-500 dark:border-zinc-700">
                            هنوز داده کافی برای رتبه‌بندی نیست.
                        </li>
                    @endforelse
                </ol>
            </div>
        @endforeach
    </div>
    </div>
</div>
