<div class="space-y-8">
    <div class="flex flex-wrap items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-semibold tracking-tight">{{ $connection ? 'ویرایش اتصال VoIP' : 'افزودن اتصال VoIP' }}</h1>
        </div>
        <a href="{{ route('employer.voip.connections.index') }}" class="saas-btn-secondary">بازگشت</a>
    </div>

    <form wire:submit="save" class="saas-card max-w-3xl space-y-6">
        <div class="grid gap-4 md:grid-cols-2">
            <div class="md:col-span-2">
                <label class="mb-1 block text-sm font-medium">ارائه‌دهنده</label>
                <select wire:model.live="voip_provider_id" class="saas-input" required>
                    @foreach ($providers as $provider)
                        <option value="{{ $provider->id }}">
                            {{ \App\Domain\Voip\Enums\VoipProviderCode::tryFrom($provider->code)?->label() ?? $provider->name }}
                        </option>
                    @endforeach
                </select>
                @if ($this->isCustomProvider)
                    <p class="mt-1 text-xs text-zinc-500">{{ __('ui.voip.custom_provider_hint') }}</p>
                @endif
            </div>
            <div class="md:col-span-2">
                <label class="mb-1 block text-sm font-medium">نام اتصال</label>
                <input wire:model="name" class="saas-input" required>
                @error('name') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
            </div>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" wire:model="is_default"> پیش‌فرض</label>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" wire:model="is_active"> فعال</label>
        </div>

        @unless ($this->isCustomProvider)
            <div class="border-t border-zinc-200 pt-6 dark:border-zinc-800">
                <h2 class="mb-4 font-semibold">اعتبارنامه API</h2>
                <div class="grid gap-4 md:grid-cols-2">
                    <div class="md:col-span-2">
                        <label class="mb-1 block text-sm font-medium">آدرس API</label>
                        <input wire:model="api_url" class="saas-input" placeholder="http://c53.hostedastel.ir/api/v4">
                        <p class="mt-1 text-xs text-zinc-500">برای سیموتل/Astel معمولاً آدرس سرور به‌همراه /api/v4 است (حروف کوچک).</p>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium">کلید API</label>
                        <input wire:model="api_key" type="password" class="saas-input" placeholder="{{ $connection ? 'خالی = بدون تغییر' : 'X-APIKEY از Astel' }}">
                        <p class="mt-1 text-xs text-zinc-500">همان X-APIKEY؛ یکی از کلید یا توکن کافی است.</p>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium">توکن API</label>
                        <input wire:model="api_token" type="password" class="saas-input" placeholder="{{ $connection ? 'خالی = بدون تغییر' : '' }}">
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium">نام کاربری API (Basic Auth)</label>
                        <input wire:model="username" class="saas-input" placeholder="طبق مستندات سیموتل همراه با API Key">
                        <p class="mt-1 text-xs text-zinc-500">سیموتل معمولاً X-APIKEY + Basic Auth را با هم می‌خواهد. بدون دسترسی reports/quick وضعیت تماس از API خوانده نمی‌شود.</p>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium">رمز عبور</label>
                        <input wire:model="password" type="password" class="saas-input" placeholder="{{ $connection ? 'خالی = بدون تغییر' : '' }}">
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium">Timeout (ثانیه)</label>
                        <input wire:model="timeout" type="number" class="saas-input">
                    </div>
                    <div class="md:col-span-2">
                        <label class="mb-1 block text-sm font-medium">کانتکس سیموتل / Astel</label>
                        <input wire:model="simotel_context" class="saas-input font-mono text-sm" placeholder="مثلاً c2191093492" dir="ltr">
                        <p class="mt-1 text-xs text-zinc-500">شناسه tenant برای ردیابی؛ در درخواست API ارسال نمی‌شود.</p>
                    </div>
                </div>
            </div>
        @else
            <div class="border-t border-zinc-200 pt-6 dark:border-zinc-800 space-y-6">
                @if ($this->amiIngestionAvailable)
                    <div>
                        <h2 class="mb-3 font-semibold">{{ __('ui.voip.ingestion_method_title') }}</h2>
                        <div class="grid gap-3 md:grid-cols-2">
                            <label class="flex cursor-pointer items-start gap-3 rounded-lg border p-3 {{ $ingestion_mode === 'webhook' ? 'border-sky-400 bg-sky-50 dark:border-sky-700 dark:bg-sky-950/30' : 'border-zinc-200 dark:border-zinc-800' }}">
                                <input type="radio" wire:model.live="ingestion_mode" value="webhook" class="mt-1">
                                <span>
                                    <span class="block font-medium">{{ __('ui.voip.ingestion_webhook_title') }}</span>
                                    <span class="mt-1 block text-xs text-zinc-500">{{ __('ui.voip.ingestion_webhook_hint') }}</span>
                                </span>
                            </label>
                            <label class="flex cursor-pointer items-start gap-3 rounded-lg border p-3 {{ $ingestion_mode === 'ami' ? 'border-violet-400 bg-violet-50 dark:border-violet-700 dark:bg-violet-950/30' : 'border-zinc-200 dark:border-zinc-800' }}">
                                <input type="radio" wire:model.live="ingestion_mode" value="ami" class="mt-1">
                                <span>
                                    <span class="block font-medium">{{ __('ui.voip.ingestion_ami_title') }}</span>
                                    <span class="mt-1 block text-xs text-zinc-500">{{ __('ui.voip.ingestion_ami_hint') }}</span>
                                </span>
                            </label>
                        </div>
                    </div>
                @endif

                @if ($this->amiIngestionAvailable && $ingestion_mode === 'ami')
                    <div class="grid gap-4 md:grid-cols-2">
                        <div>
                            <label class="mb-1 block text-sm font-medium">{{ __('ui.voip.ami_host_label') }}</label>
                            <input wire:model="ami_host" class="saas-input font-mono text-sm" placeholder="10.0.0.20" dir="ltr">
                            @error('ami_host') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="mb-1 block text-sm font-medium">{{ __('ui.voip.ami_port_label') }}</label>
                            <input wire:model="ami_port" type="number" class="saas-input font-mono text-sm" dir="ltr">
                            @error('ami_port') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="mb-1 block text-sm font-medium">{{ __('ui.voip.ami_username_label') }}</label>
                            <input wire:model="ami_username" class="saas-input font-mono text-sm" dir="ltr">
                            @error('ami_username') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="mb-1 block text-sm font-medium">{{ __('ui.voip.ami_password_label') }}</label>
                            <input wire:model="ami_password" type="password" class="saas-input font-mono text-sm" placeholder="{{ $connection ? __('ui.voip.ami_password_unchanged') : '' }}" dir="ltr">
                            @error('ami_password') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
                        </div>
                    </div>

                    @include('livewire.employer.voip.partials.asterisk-ami-guide', [
                        'amiHost' => $ami_host,
                        'amiPort' => $ami_port,
                        'amiUsername' => $ami_username ?: 'callcenter-ai',
                        'connectionId' => $connection?->id,
                    ])
                @else
                    @include('livewire.employer.voip.partials.asterisk-guide', [
                        'webhookUrl' => $connection?->inbound_webhook_url,
                        'organizationId' => $connection?->organization_id ?? \App\Services\EmployerContext::organizationId(),
                        'webhookToken' => $connection?->webhook_token,
                        'connectionId' => $connection?->id,
                        'incomingCallUrl' => url('/api/voip/incoming-call'),
                    ])
                @endif
            </div>
        @endunless

        <div class="border-t border-zinc-200 pt-6 dark:border-zinc-800 space-y-4">
            <h2 class="font-semibold">وب‌هوک</h2>

            @if ($connection)
                <x-saas.webhook-url :url="$connection->inbound_webhook_url" />
            @else
                <p class="text-sm text-zinc-500">پس از ذخیره، آدرس وب‌هوک اختصاصی اینجا نمایش داده می‌شود.</p>
            @endif

            <div>
                <label class="mb-1 block text-sm font-medium">کد امنیتی وب‌هوک (اختیاری — ۴۸ کاراکتر)</label>
                <input wire:model="webhook_token" class="saas-input font-mono text-sm" placeholder="{{ $connection ? 'خالی = بدون تغییر' : 'خالی = خودکار' }}">
                @error('webhook_token') <p class="mt-1 text-sm text-red-600">{{ $message }}</p> @enderror
            </div>

            @if ($this->isCustomProvider)
                <div>
                    <label class="mb-1 block text-sm font-medium">نگاشت فیلدهای وب‌هوک (JSON)</label>
                    <textarea wire:model="webhook_field_mapping_json" rows="4" class="saas-input font-mono text-xs" dir="ltr"></textarea>
                </div>
            @endif

            <div>
                <label class="mb-1 block text-sm font-medium">نگاشت داخلی (JSON)</label>
                <textarea wire:model="extension_mapping_json" rows="4" class="saas-input font-mono text-xs" dir="ltr" placeholder='{"982191093492":"101"}'></textarea>
                <p class="mt-1 text-xs text-zinc-500">کلید: DID یا شماره فیزیکی؛ مقدار: داخلی کارشناس (مثلاً 982191093492 → 101).</p>
            </div>
            <div>
                <label class="mb-1 block text-sm font-medium">تنظیمات ضبط (JSON)</label>
                <textarea wire:model="recording_settings_json" rows="4" class="saas-input font-mono text-xs" dir="ltr"></textarea>
            </div>
        </div>

        <div class="flex flex-wrap gap-2">
            <button type="submit" class="saas-btn-primary">ذخیره</button>
            @if ($connection)
                <button type="button" wire:click="test" class="saas-btn-secondary">تست اتصال</button>
                <button type="button" wire:click="sync" class="saas-btn-secondary">همگام‌سازی داخلی‌ها</button>
                <button type="button" wire:click="regenerateToken" wire:confirm="{{ __('ui.voip.webhook_regenerate_confirm') }}" class="saas-btn-secondary">تغییر توکن وب‌هوک</button>
            @endif
        </div>
    </form>
</div>
