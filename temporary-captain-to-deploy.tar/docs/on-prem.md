# استقرار محلی (on-prem) — راهنمای کامل از سرور خام تا تحویل

هدف: همان محصول را روی LAN کارفرما با **یک سازمان** نصب کنید.

| نقش | آدرس | چه کسی |
|-----|------|--------|
| ادمین پلتفرم | `/admin` | **فقط شما** (کارفرما این را لازم ندارد) |
| کارفرما | `/app` | مدیر سازمان مشتری |
| کارشناس | `/workspace` | اپراتورها |

Asterisk/Simotel **لازم نیست** روی همان سرور اپ باشد؛ IP داخلی جدا کافی است، فقط باید در شبکه به هم برسند.

---

## ۰. جواب سریع به سوال‌های پرتکرار

### رمز ادمین از کجاست؟ «دیگه رمز نداره» یعنی چه؟

رمز از پیش‌ساختهٔ مخفی در محصول **وجود ندارد**. شما خودتان قبل از seed در فایل `.env` می‌نویسید:

```env
ONPREM_ADMIN_EMAIL=mehdi@yourcompany.com
ONPREM_ADMIN_PASSWORD=یک-رمز-قوی-که-خودت-انتخاب-میکنی
ONPREM_EMPLOYER_EMAIL=manager@customer.local
ONPREM_EMPLOYER_PASSWORD=رمز-کارفرما
```

بعد دستور `OnPremSeeder` همان ایمیل/رمز را در دیتابیس می‌سازد.

| ورود | آدرس | ایمیل | رمز |
|------|------|--------|-----|
| ادمین شما | `http://IP-سرور/admin` | مقدار `ONPREM_ADMIN_EMAIL` | مقدار `ONPREM_ADMIN_PASSWORD` |
| کارفرما | `http://IP-سرور/app` | مقدار `ONPREM_EMPLOYER_EMAIL` | مقدار `ONPREM_EMPLOYER_PASSWORD` |

اگر seeder را با مقادیر مثال (`change-me-admin-password`) زده باشید، همان‌ها رمز ورود هستند — **قبل از تحویل عوضشان کنید** (یا `.env` را درست کنید و دوباره seed بزنید / از ادمین رمز را reset کنید).

`PlatformFoundationSeeder` داخل همان فرآیند ممکن است کاربر قدیمی `admin@example.com` / `password` هم بسازد؛ برای on-prem فقط از اکانتی که با `ONPREM_ADMIN_*` ساختید استفاده کنید و در صورت تمایل کاربرهای مثال را بعداً از ادمین حذف کنید.

### باید zip کنم ببرم روی سرور؟

**یکی از این سه روش** — zip کاملاً معتبر است، مخصوصاً وقتی سرور مشتری به Git شما دسترسی ندارد:

| روش | کی مناسب است |
|-----|----------------|
| **A) zip + USB/scp** | سرور خام / بدون دسترسی Git — پیشنهادی برای بیشتر مشتریان |
| **B) git clone** | سرور به ریپو دسترسی دارد و اینترنت دارد |
| **C) ایمیج Docker آماده** | وقتی روی لپ‌تاپ build کرده‌اید و می‌خواهید روی سرور فقط `load` کنید |

جزئیات هر روش در بخش ۲ آمده است.

---

## ۱. پیش‌نیازها (قبل از رفتن پیش مشتری)

روی **لپ‌تاپ خودتان** یا هر جایی که کد را دارید:

- [ ] نسخهٔ پایدار پروژه (همان commitی که می‌خواهید نصب شود)
- [ ] IP پیشنهادی سرور اپ در LAN مشتری (مثلاً `10.0.0.50`)
- [ ] IP سرور Asterisk/Simotel (مثلاً `10.0.0.20`) — اگر جداست
- [ ] ایمیل/رمز ادمین (مال شما) و ایمیل/رمز کارفرما (مال مشتری)
- [ ] کلید API مدل LLM (برای مرحلهٔ بعد از نصب)
- [ ] فلش/دسترسی scp به سرور مشتری

روی **سرور مشتری** (خام):

- [ ] Linux (Ubuntu 22.04/24.04 پیشنهاد می‌شود)
- [ ] حداقل ~2 CPU، 4GB RAM، 40GB دیسک (بیشتر اگر ضبط صدا زیاد است)
- [ ] IP ثابت در LAN
- [ ] خروجی اینترنت برای: نصب Docker + pull ایمیج PostgreSQL + API هوش مصنوعی
- [ ] دسترسی SSH با sudo

---

## ۲. انتقال کد به سرور

### روش A — zip (پیشنهادی برای سرور خام بدون Git)

روی لپ‌تاپ، از ریشهٔ پروژه:

```bash
chmod +x scripts/package-onprem.sh
./scripts/package-onprem.sh
# خروجی مثلاً: dist/avayar-onprem-YYYYMMDD.zip
```

بعد انتقال:

```bash
# مثال با scp:
scp dist/avayar-onprem-*.zip user@10.0.0.50:/tmp/

# روی سرور:
sudo mkdir -p /opt/callcenter
sudo unzip /tmp/avayar-onprem-*.zip -d /opt/callcenter
cd /opt/callcenter
```

یا کپی با فلش به همان مسیر.

اسکریپت `vendor` و `node_modules` را عمداً داخل zip نمی‌گذارد؛ روی سرور با Docker **build** می‌شوند (نیاز به اینترنت در زمان build).

### روش B — git clone

```bash
sudo mkdir -p /opt/callcenter
sudo git clone <URL-ریپو> /opt/callcenter
cd /opt/callcenter
sudo git checkout <tag-یا-branch-پایدار>
```

### روش C — ایمیج از پیش ساخته

روی لپ‌تاپ (با اینترنت):

```bash
docker compose -f docker-compose.onprem.yml build
docker save callcenter-app:latest | gzip > avayar-app.tar.gz
# نام ایمیج را با docker images چک کنید
```

روی سرور:

```bash
gunzip -c avayar-app.tar.gz | docker load
# کد/compose و .env را هم باید روی سرور داشته باشید (حداقل zip سبک)
```

برای اکثر نصب‌ها روش A ساده‌تر است.

---

## ۳. آماده‌سازی سرور خام (یک‌بار)

دستورها برای Ubuntu/Debian. با کاربر دارای sudo:

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl unzip git

# نصب Docker (رسمی)
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"
# یک‌بار logout/login کنید تا گروه docker اعمال شود

docker --version
docker compose version
```

فایروال (اگر ufw روشن است) — پورت وب اپ را باز کنید (پیش‌فرض compose: `80`):

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
# اگر realtime می‌خواهید:
# sudo ufw allow 8090/tcp
sudo ufw enable
```

اگر قبلاً روی `:8000` بودید و می‌خواهید به پورت ۸۰ بروید، در `.env` بگذارید `APP_URL=http://IP-LAN` و `ONPREM_HTTP_PORT=80`، بعد `docker compose -f docker-compose.onprem.yml up -d` و `php artisan config:clear`. آدرس وب‌هوک Asterisk را بدون `:8000` دوباره از UI کپی کنید. داخل کانتینر از قبل nginx هست؛ Docker فقط `80→8000` را map می‌کند و reverse proxy جدا روی هاست لازم نیست مگر TLS بخواهید.

IP سرور را یادداشت کنید:

```bash
hostname -I
```

---

## ۴. تنظیم `.env` (رمزها همین‌جا تعریف می‌شوند)

```bash
cd /opt/callcenter
cp .env.onprem.example .env
nano .env   # یا vim
```

### ۴.۱ موارد اجباری

| متغیر | چه بگذارید |
|--------|------------|
| `APP_URL` | `http://10.0.0.50` — **IP واقعی LAN همین سرور اپ** (نه `localhost` اگر Asterisk جای دیگری است). پورت پیش‌فرض `80` است؛ اگر پورت دیگری گذاشتید در URL هم بیاورید |
| `FORCE_HTTPS` | برای LAN بدون TLS: `false` |
| `SESSION_SECURE_COOKIE` | برای LAN بدون TLS: `false` (وگرنه لاگین «منقضی / expired» می‌شود) |
| `APP_KEY` | فعلاً خالی بگذارید؛ بعد از بالا آمدن کانتینر generate می‌کنیم |
| `DB_PASSWORD` | یک رمز قوی برای PostgreSQL |
| `ONPREM_ADMIN_EMAIL` | ایمیل ورود شما به `/admin` |
| `ONPREM_ADMIN_PASSWORD` | **رمز ادمین شما** (خودتان انتخاب کنید) |
| `ONPREM_EMPLOYER_EMAIL` | ایمیل کارفرما برای `/app` |
| `ONPREM_EMPLOYER_PASSWORD` | رمز کارفرما |
| `ONPREM_ORG_TITLE` | نام سازمان مشتری |
| `ONPREM_ENABLED` | `true` در compose محلی برای نصب تک‌سازمانی |
| `RECORDINGS_DISK` | `local` (همین پیش‌فرض مثال) |

نمونهٔ حداقلی برای بخش کاربران:

```env
APP_URL=http://10.0.0.50
ONPREM_HTTP_PORT=80

FORCE_HTTPS=false
SESSION_SECURE_COOKIE=false

DB_PASSWORD=Db!StrongPass-ChangeMe

ONPREM_ADMIN_NAME="Mehdi"
ONPREM_ADMIN_EMAIL=mehdi@yourcompany.com
ONPREM_ADMIN_PASSWORD=Admin!StrongPass-ChangeMe

ONPREM_EMPLOYER_NAME="مدیر مرکز تماس"
ONPREM_EMPLOYER_EMAIL=manager@customer.local
ONPREM_EMPLOYER_PASSWORD=Employer!Pass-ChangeMe

ONPREM_ORG_TITLE="شرکت نمونه"
ONPREM_EMPLOYER_CAN_MANAGE_INTEGRATIONS=true
```

`ONPREM_EMPLOYER_CAN_MANAGE_INTEGRATIONS=true` یعنی کارفرما در `/app` بتواند اتصال VoIP/webhook را ببیند؛ اگر می‌خواهید فقط شما از `/admin` تنظیم کنید، `false` بگذارید.

ارائه‌دهندگان و مدل‌های LLM از `/admin` قابل تنظیم هستند. تحلیل تماس به اعتبار یا کیف پول وابسته نیست.

---

## ۵. بالا آوردن سرویس‌ها و ساخت کلید

```bash
cd /opt/callcenter
docker compose -f docker-compose.onprem.yml up -d --build
```

اولین build چند دقیقه طول می‌کشد (اینترنت لازم است).

صبر کنید تا healthy شود:

```bash
docker compose -f docker-compose.onprem.yml ps
docker compose -f docker-compose.onprem.yml logs -f app
# با Ctrl+C از لاگ خارج شوید وقتی migrate تمام شد
```

ساخت `APP_KEY` (اگر خالی بود):

```bash
docker compose -f docker-compose.onprem.yml exec app php artisan key:generate --force
```

چک سلامت:

```bash
curl -sS -o /dev/null -w "%{http_code}\n" http://127.0.0.1/up
# انتظار: 200
```

از یک سیستم در LAN:

مرورگر → `http://10.0.0.50` (IP خودتان)

اختیاری — realtime (Reverb):

```bash
docker compose -f docker-compose.onprem.yml --profile realtime up -d
```

---

## ۶. بوت‌استرپ یک سازمان (ساخت ادمین + کارفرما)

**فقط `key:generate` کاربر نمی‌سازد.** بعد از اینکه `.env` رمزها را درست نوشته‌اید:

```bash
# اگر .env را بعد از up اول ویرایش کردید، حتماً recreate تا ONPREM_* داخل کانتینر بیاید:
docker compose -f docker-compose.onprem.yml up -d --force-recreate app

docker compose -f docker-compose.onprem.yml exec app php artisan config:clear
docker compose -f docker-compose.onprem.yml exec app php artisan db:seed --class=OnPremSeeder --force
```

این کار انجام می‌دهد:

1. ارائه‌دهنده‌های CRM / VoIP / LLM و تنظیمات پلتفرم
2. کاربر SuperAdmin با `ONPREM_ADMIN_*`
3. کاربر Employer + یک Organization با `ONPREM_EMPLOYER_*` / `ONPREM_ORG_TITLE`
4. شارژ اولیهٔ کیف‌پول AI
5. **بدون** دادهٔ دمو چندسازمانه

ورود آزمایشی:

| نقش | آدرس | اعتبار |
|-----|------|--------|
| ادمین شما | `/admin` | `ONPREM_ADMIN_EMAIL` + `ONPREM_ADMIN_PASSWORD` |
| کارفرما | `/login` → `/app` | `ONPREM_EMPLOYER_EMAIL` + `ONPREM_EMPLOYER_PASSWORD` |

اگر Filament می‌گوید «مشخصات واردشده با اطلاعات ما سازگار نیست»:

```bash
# لیست ایمیل‌های موجود
docker compose -f docker-compose.onprem.yml exec app php artisan tinker --execute="echo App\Models\User::query()->pluck('email')->join(PHP_EOL);"

# seed دوباره با رمز فعلی .env
docker compose -f docker-compose.onprem.yml up -d --force-recreate app
docker compose -f docker-compose.onprem.yml exec app php artisan config:clear
docker compose -f docker-compose.onprem.yml exec app php artisan db:seed --class=OnPremSeeder --force
```

با ایمیل/رمز **دقیقاً همان** `ONPREM_ADMIN_*` داخل `.env` وارد `/admin` شوید (نه لزوماً `admin@example.com` مگر همان را نوشته باشید).

---

## ۷. پیکربندی بعد از نصب (با هم در `/admin`)

با اکانت ادمین خودتان:

1. **LLM:** کلید API ارائه‌دهنده و مدل پیش‌فرض پلتفرم را تنظیم کنید  
2. **کیف‌پول:** در صورت نیاز شارژ بیشتر برای سازمان  
3. **VoIP:** اتصال سازمان را بسازید (بخش ۸)  
4. **کارشناسان:** کاربران employee بسازید و extension را نگاشت کنید  
5. رمز ورود را به کارفرما بدهید (`/app`) — پنل `/admin` را به آن‌ها ندهید  

---

## ۸. شبکه و VoIP (Asterisk جدا از اپ)

```text
[کارشناسان مرورگر] ──► [سرور اپ :80]
[Asterisk/Simotel IP جدا] ──POST webhook──► [اپ /webhooks/voip/{token}]
[اپ] ──فقط اگر Simotel──► [api_url داخلی]
[اپ] ──تحلیل AI──► [اینترنت]
```

### ۸.۱ Asterisk خام (سفارشی)

- نوع اتصال در ادمین/کارفرما: **سفارشی / Asterisk**
- فقط **PBX → اپ** لازم است
- URL وب‌هوک را از UI کپی کنید؛ باید با `APP_URL` یکی باشد (IP LAN اپ)
- برای **ورودی و خروجی** هر دو باید hangup handler داشته باشند و `direction` درست ارسال شود

چک از **ماشین Asterisk** (ورودی):

```bash
curl -sS -o /dev/null -w "%{http_code}\n" \
  -X POST "http://10.0.0.50/webhooks/voip/<TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"event":"call.ended","call_id":"test-in-1","direction":"inbound","from":"09120000000","to":"1001","extension":"1001","status":"answered","duration":10}'
```

چک خروجی:

```bash
curl -sS -o /dev/null -w "%{http_code}\n" \
  -X POST "http://10.0.0.50/webhooks/voip/<TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"event":"call.ended","call_id":"test-out-1","direction":"outbound","from":"1001","to":"09129876543","extension":"1001","status":"answered","duration":20}'
```

انتظار معمول: `202`. اگر وصل نشد → فایروال یا IP/پورت اشتباه.

در dialplan:

- کانتکست ورودی: `Set(CC_DIRECTION=inbound)` سپس `Goto(callcenter-cdr,h,1)`
- کانتکست خروجی (`from-internal` / dialout): `Set(CC_DIRECTION=outbound)` سپس همان Goto
- خروجی: `from` و `extension` = داخلی کارشناس، `to` = شماره مشتری

نمونه کامل dialplan داخل UI اتصال سفارشی هست.

### ۸.۱.۱ Asterisk AMI (Issabel + CRM مثل VoIPing)

اگر CRM دیگری hangup handler خودش را دارد و dialplan قابل تغییر نیست، در UI روش **AMI** را انتخاب کنید:

1. روی Asterisk: `vi /etc/asterisk/manager_custom.conf` — کاربر `callcenter-ai` با `read` و `write = none` (نمونه در UI).
2. بررسی: `asterisk -rx "manager show user callcenter-ai"`
3. در UI اتصال: host/port/username/password AMI را ذخیره کنید.
4. سرویس listener را اجرا کنید:

```bash
docker compose -f docker-compose.onprem.yml up -d ami
# یا داخل کانتینر:
php artisan voip:ami-listen --connection=<ID>
```

ترافیک: **اپ → Asterisk:5038** (TCP). dialplan لازم نیست.

جهت تماس از context Eventها تشخیص داده می‌شود:

| Context | جهت |
|---------|------|
| `from-trunk`, `from-pstn`, `ext-queues` | ورودی |
| `from-internal`, `macro-dialout`, `outbound`, `dialout` | خروجی |

> در cloud این گزینه به‌صورت پیش‌فرض غیرفعال است (`VOIP_AMI_ENABLED=false`) چون معمولاً دسترسی به پورت 5038 Asterisk مشتری وجود ندارد.

### ۸.۲ Simotel روی IP داخلی

- `api_url` مثل `http://10.0.0.20/api/v4`
- ترافیک **دوطرفه** لازم است

از سرور اپ:

```bash
curl -sS -o /dev/null -w "%{http_code}\n" "http://10.0.0.20/api/v4"
```

### ۸.۳ ضبط صدا

اگر `recording_url` در webhook می‌آید، سرور اپ باید آن آدرس را روی LAN باز کند؛ وگرنه تماس ثبت می‌شود ولی تحلیل صوتی کامل نمی‌شود.

### ۸.۴ فایروال

| مبدأ | مقصد | پورت |
|------|------|------|
| کارشناسان | اپ | 80 (یا `ONPREM_HTTP_PORT` / 443 با reverse proxy) |
| Asterisk/Simotel | اپ | همان پورت وب |
| اپ | Asterisk AMI | 5038 (فقط اگر روش AMI) |
| اپ | Simotel | پورت API |
| اپ | اینترنت | 443 برای LLM |

---

## ۹. چک‌لیست تحویل به کارفرما

- [ ] `/up` از LAN جواب ۲۰۰ می‌دهد
- [ ] ورود ادمین شما به `/admin` OK است
- [ ] ورود کارفرما به `/app` OK است
- [ ] حداقل یک کارشناس وارد `/workspace` می‌شود
- [ ] تست webhook ورودی و خروجی از Asterisk موفق است
- [ ] یک تماس ورودی و یک تماس خروجی آزمایشی در سیستم دیده می‌شود
- [ ] (در صورت AI) یک تحلیل آزمایشی با LLM OK است
- [ ] کارفرما **رمز `/admin` را ندارد**؛ فقط `/app`
- [ ] بکاپ اول گرفته شده (بخش ۱۰)
- [ ] رمزهای مثال در `.env` باقی نمانده‌اند

---

## ۱۰. بهره‌برداری: بکاپ، آپدیت، عیب‌یابی

### بکاپ

```bash
cd /opt/callcenter
# دیتابیس (PostgreSQL — مثل cloud)
docker compose -f docker-compose.onprem.yml exec -T postgres \
  pg_dump -U "$DB_USERNAME" "$DB_DATABASE" > backup-$(date +%F).sql

# volume ذخیره (ضبط‌ها داخل Docker volume است)
docker run --rm -v callcenter_onprem_storage:/data -v "$(pwd)":/backup alpine \
  tar czf /backup/storage-$(date +%F).tar.gz -C /data .
# نام volume را با `docker volume ls` تأیید کنید
```

### آپدیت نسخه (شما انجام می‌دهید)

```bash
cd /opt/callcenter
# اگر zip جدید آوردید: فایل‌ها را جایگزین کنید (بدون پاک کردن .env و بدون حذف volumeها)
# اگر git: git pull

docker compose -f docker-compose.onprem.yml up -d --build
```

`.env` و volumeهای PostgreSQL/storage را پاک نکنید.

### لاگ و وضعیت

```bash
docker compose -f docker-compose.onprem.yml ps
docker compose -f docker-compose.onprem.yml logs -f app
```

### خطای «Table already exists» موقع migrate

معمولاً یعنی migrate یک‌بار نیمه‌کاره مانده (جدول ساخته شده، ولی در جدول `migrations` ثبت نشده) و با restart دوباره همان migration اجرا شده.

اگر نصب هنوز تازه است و دادهٔ مهمی ندارید (ساده‌ترین راه):

```bash
cd /opt/callcenter
docker compose -f docker-compose.onprem.yml down -v   # حجم PostgreSQL و storage پاک می‌شود
docker compose -f docker-compose.onprem.yml up -d --build
# بعد دوباره key:generate و OnPremSeeder
```

اگر نمی‌خواهید volume را پاک کنید و هنوز روی MySQL قدیمی گیر کرده‌اید: به نسخهٔ جدید (PostgreSQL + FK کوتاه) مهاجرت کنید با `down -v`؛ نصب تازه on-prem از این به بعد Postgres است.

اگر خطای «Identifier name … is too long» دیدید: نسخهٔ کد را آپدیت کنید (نام FK کوتاه شده)، سپس:

```bash
docker compose -f docker-compose.onprem.yml down -v
# در .env: DB_CONNECTION=pgsql و DB_HOST=postgres
docker compose -f docker-compose.onprem.yml up -d --build
```

### لاگین «expired / صفحه منقضی شده» یا فونت بد روی HTTP

علت رایج: اپ فکر می‌کند HTTPS است (مخصوص cloud/CapRover) ولی مرورگر با `http://` باز شده → کوکی سشن ست نمی‌شود → CSRF fail.

در `.env` سرور:

```env
APP_URL=http://IP-LAN
FORCE_HTTPS=false
SESSION_SECURE_COOKIE=false
```

بعد:

```bash
docker compose -f docker-compose.onprem.yml up -d --build
docker compose -f docker-compose.onprem.yml exec app php artisan config:clear
```

مرورگر: یک‌بار کوکی‌های همان سایت را پاک کنید و دوباره لاگین کنید.

فونت Vazirmatn به‌صورت محلی از `/css/vazirmatn.css` و `/fonts/vazirmatn/` لود می‌شود (لاگین و پنل ادمین Filament؛ بدون Google/Bunny CDN).

اگر بعد از آپدیت هنوز فونت سیستم دیده می‌شود، یک‌بار هارد رفرش کنید و مطمئن شوید فایل‌های `public/fonts/vazirmatn` داخل ایمیج/zip هستند.

### مدل عملیاتی با مشتری

- نصب و تنظیمات اولیه را **با هم** انجام می‌دهید؛ ادمین پلتفرم نزد شما می‌ماند
- آپدیت و بکاپ مسئولیت شماست (SSH/VPN یا حضور)
- بدون اینترنت خروجی برای API مدل، تحلیل AI کار نمی‌کند — قبل از قرارداد بگویید
- داخل LAN معمولاً HTTP کافی است؛ اگر از بیرون/VPN دارند TLS بگذارید و `APP_URL` را `https://...` کنید

---

## ۱۱. خلاصهٔ مسیر شما از صفر تا انتها

```text
1. روی لپ‌تاپ: ./scripts/package-onprem.sh  →  فایل zip
2. zip را به سرور خام ببرید (scp / فلش) و در /opt/callcenter باز کنید
3. Docker را روی سرور نصب کنید
4. cp .env.onprem.example .env  →  APP_URL + رمز ادمین/کارفرما/DB
5. docker compose -f docker-compose.onprem.yml up -d --build
6. php artisan key:generate --force  (داخل کانتینر app)
7. php artisan db:seed --class=OnPremSeeder --force
8. ورود /admin با ONPREM_ADMIN_*  →  LLM + VoIP + کارشناسان
9. تست webhook از Asterisk
10. تحویل /app به کارفرما + بکاپ اول
```

---

## ۱۲. چیزهایی که عمداً انجام نمی‌دهیم

- محصول جدا یا حذف پنل ادمین
- اجبار به نصب Asterisk روی همان ماشین اپ
- دیتابیس جدا per-tenant

فایل‌های مرتبط: `.env.onprem.example`، `docker-compose.onprem.yml`، `database/seeders/OnPremSeeder.php`، `scripts/package-onprem.sh`
