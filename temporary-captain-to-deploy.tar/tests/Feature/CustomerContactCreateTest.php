<?php

namespace Tests\Feature;

use App\Enums\UserRole;
use App\Livewire\Employer\Customers\Contacts\Create as ContactCreate;
use App\Livewire\Employer\Customers\Index as CustomersHub;
use App\Models\Customer;
use App\Models\CustomerCompany;
use App\Models\Organization;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerContactCreateTest extends TestCase
{
    use RefreshDatabase;

    public function test_employer_can_create_a_contact_from_the_customers_hub_action(): void
    {
        $organization = $this->actingAsEmployer();
        $company = CustomerCompany::query()->create([
            'organization_id' => $organization->id,
            'name' => 'شرکت همراه',
        ]);

        Livewire::test(ContactCreate::class)
            ->assertSee('شخص جدید')
            ->set('name', 'علی رضایی')
            ->set('phone_number', '09123334455')
            ->set('email', 'ali@example.com')
            ->set('job_title', 'مدیر خرید')
            ->set('customer_company_id', $company->id)
            ->call('save')
            ->assertHasNoErrors()
            ->assertRedirect(route('employer.customers.show', Customer::query()->first()));

        $this->assertDatabaseHas('customers', [
            'organization_id' => $organization->id,
            'name' => 'علی رضایی',
            'phone_number' => '09123334455',
            'normalized_phone' => '09123334455',
            'email' => 'ali@example.com',
            'job_title' => 'مدیر خرید',
            'customer_company_id' => $company->id,
            'company_name' => 'شرکت همراه',
        ]);
    }

    public function test_duplicate_phone_in_the_same_organization_is_rejected(): void
    {
        $organization = $this->actingAsEmployer();
        Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'شخص قبلی',
            'phone_number' => '09120001111',
            'normalized_phone' => '09120001111',
        ]);

        Livewire::test(ContactCreate::class)
            ->set('name', 'شخص تکراری')
            ->set('phone_number', '09120001111')
            ->call('save')
            ->assertHasErrors(['phone_number']);

        $this->assertSame(1, Customer::query()->where('organization_id', $organization->id)->count());
    }

    public function test_equivalent_iranian_phone_formats_are_rejected_as_duplicates(): void
    {
        $organization = $this->actingAsEmployer();
        Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'شخص قبلی',
            'phone_number' => '09120001111',
            'normalized_phone' => '09120001111',
        ]);

        Livewire::test(ContactCreate::class)
            ->set('name', 'شخص تکراری')
            ->set('phone_number', '+98 912 000 1111')
            ->call('save')
            ->assertHasErrors(['phone_number']);

        $this->assertSame(1, Customer::query()->where('organization_id', $organization->id)->count());
    }

    public function test_hub_add_dialog_creates_a_contact_and_a_company(): void
    {
        $organization = $this->actingAsEmployer();
        $company = CustomerCompany::query()->create([
            'organization_id' => $organization->id,
            'name' => 'شرکت همراه',
            'normalized_name' => 'شرکت همراه',
        ]);

        Livewire::test(CustomersHub::class)
            ->assertSee('افزودن')
            ->call('openCreateDialog')
            ->assertSet('showCreateDialog', true)
            ->assertSet('createMode', 'contact')
            ->assertSee('ایجاد شخص')
            ->set('contactName', 'علی رضایی')
            ->set('jobTitle', 'مدیر خرید')
            ->set('customerCompanyId', (string) $company->id)
            ->set('phoneNumber', '09123334455')
            ->set('contactEmail', 'ali@example.com')
            ->call('saveCreateDialog')
            ->assertHasNoErrors()
            ->assertSet('showCreateDialog', false);

        $this->assertDatabaseHas('customers', [
            'organization_id' => $organization->id,
            'name' => 'علی رضایی',
            'phone_number' => '09123334455',
            'job_title' => 'مدیر خرید',
            'customer_company_id' => $company->id,
        ]);

        Livewire::test(CustomersHub::class)
            ->call('openCreateDialog', 'company')
            ->assertSet('createMode', 'company')
            ->assertSee('ایجاد شرکت')
            ->set('companyName', 'آوا تجارت')
            ->set('industry', 'فناوری')
            ->set('website', 'example.com')
            ->set('companyPhone', '02100000000')
            ->set('companyEmail', 'info@example.com')
            ->call('saveCreateDialog')
            ->assertHasNoErrors()
            ->assertSet('showCreateDialog', false);

        $this->assertDatabaseHas('customer_companies', [
            'organization_id' => $organization->id,
            'name' => 'آوا تجارت',
            'industry' => 'فناوری',
            'email' => 'info@example.com',
        ]);
    }

    private function actingAsEmployer(): Organization
    {
        $employer = User::factory()->create(['role' => UserRole::Employer]);
        $organization = Organization::factory()->create(['user_id' => $employer->id]);

        $this->actingAs($employer);

        return $organization;
    }
}
