<?php

namespace Tests\Feature;

use App\Domain\Call\Enums\CallProcessingStatus;
use App\Domain\Call\Enums\ConversationSource;
use App\Domain\Voip\Enums\VoipProviderCode;
use App\DTOs\AnalysisListFilter;
use App\Enums\ReportDatePreset;
use App\Infrastructure\Voip\Adapters\NullVoipAdapter;
use App\Models\Call;
use App\Models\CallRecording;
use App\Models\EmployeeIntegrationMeta;
use App\Models\Organization;
use App\Models\OrganizationUser;
use App\Models\OrganizationVoipConnection;
use App\Models\User;
use App\Models\VoipCallLog;
use App\Models\VoipProvider;
use App\Services\AnalysisListQuery;
use App\Services\EmployerDashboardAnalytics;
use App\Services\Reports\ChartHolidayCalendar;
use App\Services\Reports\OrganizationCallMetrics;
use Database\Seeders\PlatformFoundationSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class OrganizationCallMetricsTest extends TestCase
{
    use RefreshDatabase;

    public function test_counts_todays_calls_from_call_records_not_only_voip_logs(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $employee = $this->employee($organization);

        $this->createCall($organization, [
            'organization_user_id' => $employee->id,
            'external_call_id' => 'metrics-test-today',
            'started_at' => now()->startOfDay()->addHours(10),
            'ended_at' => now()->startOfDay()->addHours(10)->addMinutes(5),
        ]);

        $metrics = app(OrganizationCallMetrics::class);

        $this->assertSame(1, $metrics->countToday($organization->id));
        $this->assertSame(1, EmployerDashboardAnalytics::forOrganization($organization->id)->cockpit()['calls_today']);
    }

    public function test_counts_todays_orphan_voip_logs_on_defined_extensions(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $employee = $this->employee($organization);
        $connection = $this->voipConnection($organization);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $employee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'orphan-defined-today',
            'direction' => 'inbound',
            'source_number' => '09120000099',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now('Asia/Tehran')->startOfDay()->addHours(9)->utc(),
            'recording_url' => 'https://pbx.example/monitor/exten-101-today.wav',
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        $this->assertSame(1, app(OrganizationCallMetrics::class)->countToday($organization->id));

        $overview = app(AnalysisListQuery::class)->overview(
            AnalysisListFilter::make(
                organizationId: $organization->id,
                preset: ReportDatePreset::Today,
            ),
        );

        $this->assertSame(1, $overview['total_calls'], 'analysis Today total_calls must match dashboard calls today');
    }

    public function test_ignores_calls_outside_today_window(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $employee = $this->employee($organization);

        $this->createCall($organization, [
            'organization_user_id' => $employee->id,
            'external_call_id' => 'metrics-test-yesterday',
            'started_at' => now()->subDay()->setTime(15, 30),
            'ended_at' => now()->subDay()->setTime(15, 35),
        ]);

        $this->assertSame(0, app(OrganizationCallMetrics::class)->countToday($organization->id));
    }

    public function test_counts_todays_calls_when_voip_webhook_omitted_started_at(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $employee = $this->employee($organization);

        $this->createCall($organization, [
            'organization_user_id' => $employee->id,
            'external_call_id' => 'metrics-test-null-start',
            'provider_code' => 'custom',
            'source' => ConversationSource::Voip,
            'receiver_number' => '41909000',
            'processing_status' => CallProcessingStatus::Pending,
            'started_at' => null,
            'ended_at' => null,
            'duration_seconds' => 180,
        ]);

        $this->assertSame(1, app(OrganizationCallMetrics::class)->countToday($organization->id));
        $this->assertSame(
            1,
            EmployerDashboardAnalytics::forOrganization($organization->id)->cockpit()['calls_today'],
        );
    }

    public function test_excludes_unassigned_voip_logs_from_today_count_when_filter_disabled(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $organization->update([
            'call_intake_filters' => [
                'unassigned_agent_calls' => false,
                'internal_agent_calls' => true,
            ],
        ]);
        $employee = $this->employee($organization);
        $connection = $this->voipConnection($organization);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $employee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'assigned-today',
            'direction' => 'inbound',
            'source_number' => '09120000001',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(10),
        ]);
        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'queue-unassigned',
            'direction' => 'inbound',
            'source_number' => '09120000002',
            'destination_number' => '41909000',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(11),
        ]);

        $this->assertSame(
            $this->analysisTodayTotal($organization->id),
            app(OrganizationCallMetrics::class)->countToday($organization->id),
        );
        $this->assertSame(1, app(OrganizationCallMetrics::class)->countToday($organization->id));
    }

    public function test_dashboard_today_matches_analysis_total_with_defined_extensions(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $organization->update([
            'call_intake_filters' => [
                'unassigned_agent_calls' => false,
                'internal_agent_calls' => true,
            ],
        ]);
        $definedEmployee = $this->employee($organization, 'Ali', 'Agent');
        $connection = $this->voipConnection($organization);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $definedEmployee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'defined-ext-101',
            'direction' => 'inbound',
            'source_number' => '09120000001',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(9),
        ]);
        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'orphan-unmatched',
            'direction' => 'inbound',
            'source_number' => '09120000002',
            'destination_number' => '41909000',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(11),
            'raw_payload' => ['resolved_extension' => '5001'],
        ]);

        $today = $this->analysisTodayTotal($organization->id);
        $this->assertSame(1, $today);
        $this->assertSame($today, app(OrganizationCallMetrics::class)->countToday($organization->id));
        $this->assertSame(
            $today,
            EmployerDashboardAnalytics::forOrganization($organization->id)->cockpit()['calls_today'],
        );
    }

    public function test_counts_voip_logs_on_defined_extensions_same_as_analysis_page(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $organization->update([
            'call_intake_filters' => [
                'unassigned_agent_calls' => false,
                'internal_agent_calls' => true,
            ],
        ]);
        $definedEmployee = $this->employee($organization, 'Ali', 'Agent');
        $connection = $this->voipConnection($organization);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $definedEmployee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'on-defined-extension',
            'direction' => 'inbound',
            'source_number' => '09120000011',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(9),
        ]);
        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'same-agent-other-line',
            'direction' => 'inbound',
            'source_number' => '09120000012',
            'destination_number' => '5001',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(12),
        ]);

        $today = $this->analysisTodayTotal($organization->id);
        $this->assertSame(1, $today);
        $this->assertSame($today, app(OrganizationCallMetrics::class)->countToday($organization->id));
    }

    public function test_pbx_logs_without_recording_still_count_like_analysis_page(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $employee = $this->employee($organization);
        $connection = $this->voipConnection($organization);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $employee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'recorded-101',
            'direction' => 'inbound',
            'source_number' => '09120000011',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(9),
            'recording_url' => 'https://pbx.example/monitor/exten-101.wav',
        ]);
        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'silent-101',
            'direction' => 'inbound',
            'source_number' => '09120000012',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->startOfDay()->addHours(10),
            'recording_url' => null,
        ]);

        $today = $this->analysisTodayTotal($organization->id);
        $this->assertSame(2, $today);
        $this->assertSame($today, app(OrganizationCallMetrics::class)->countToday($organization->id));
    }

    public function test_extension_activity_days_are_loaded_once_per_request(): void
    {
        $this->seed(PlatformFoundationSeeder::class);

        $organization = $this->organization();
        $employee = $this->employee($organization);
        $connection = $this->voipConnection($organization);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $employee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        foreach (range(1, 6) as $index) {
            $log = VoipCallLog::query()->create([
                'organization_id' => $organization->id,
                'organization_voip_connection_id' => $connection->id,
                'provider_code' => VoipProviderCode::Custom->value,
                'external_call_id' => 'activity-day-'.$index,
                'direction' => 'inbound',
                'source_number' => '091200000'.$index,
                'destination_number' => '101',
                'status' => 'completed',
                'started_at' => now()->startOfDay()->addHours(8 + $index),
                'raw_payload' => ['resolved_extension' => '101'],
            ]);
            $this->createCall($organization, [
                'organization_user_id' => null,
                'organization_voip_connection_id' => $connection->id,
                'voip_call_log_id' => $log->id,
                'external_call_id' => 'activity-day-'.$index,
                'receiver_number' => '101',
                'started_at' => now()->startOfDay()->addHours(8 + $index),
            ]);
        }

        DB::flushQueryLog();
        DB::enableQueryLog();

        $from = now()->startOfDay();
        $to = now()->endOfDay();
        $first = app(ChartHolidayCalendar::class)->forRange($organization->id, $from, $to);
        $firstQueries = count(DB::getQueryLog());

        DB::flushQueryLog();
        $second = app(ChartHolidayCalendar::class)->forRange($organization->id, $from, $to);

        $this->assertFalse($first->hides(now()->timezone('Asia/Tehran')->toDateString()));
        $this->assertSame(0, count(DB::getQueryLog()));
        $this->assertLessThan(12, $firstQueries);
        $this->assertFalse($second->hides(now()->timezone('Asia/Tehran')->toDateString()));
    }

    private function analysisTodayTotal(int $organizationId): int
    {
        return app(AnalysisListQuery::class)->overview(
            AnalysisListFilter::make(
                organizationId: $organizationId,
                preset: ReportDatePreset::Today,
            ),
        )['total_calls'];
    }

    private function organization(): Organization
    {
        $employer = User::factory()->employer()->create();

        return Organization::factory()->create(['user_id' => $employer->id]);
    }

    private function employee(Organization $organization, string $firstName = 'Ali', string $lastName = 'Agent'): OrganizationUser
    {
        return OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => User::factory()->employee()->create()->id,
            'first_name' => $firstName,
            'last_name' => $lastName,
            'is_active' => true,
        ]);
    }

    private function voipConnection(Organization $organization): OrganizationVoipConnection
    {
        $provider = VoipProvider::query()->where('code', VoipProviderCode::Custom->value)->first()
            ?? VoipProvider::query()->create([
                'name' => 'Custom',
                'code' => VoipProviderCode::Custom->value,
                'adapter_class' => NullVoipAdapter::class,
                'is_active' => true,
            ]);

        return OrganizationVoipConnection::query()->create([
            'organization_id' => $organization->id,
            'voip_provider_id' => $provider->id,
            'name' => 'Asterisk',
            'credentials' => [],
            'webhook_token' => str_repeat('a', 48),
            'is_default' => true,
            'is_active' => true,
            'ingestion_mode' => 'webhook',
        ]);
    }

    /** @param  array<string, mixed>  $overrides */
    private function createCall(Organization $organization, array $overrides, bool $withRecording = true): Call
    {
        $startedAt = $overrides['started_at'] ?? now()->startOfDay()->addHours(10);

        $call = Call::query()->create(array_merge([
            'organization_id' => $organization->id,
            'external_call_id' => 'metrics-call',
            'provider_code' => 'demo',
            'source' => ConversationSource::Imported,
            'direction' => 'inbound',
            'caller_number' => '09121234567',
            'receiver_number' => '02112345678',
            'status' => 'completed',
            'processing_status' => CallProcessingStatus::Analyzed,
            'started_at' => $startedAt,
            'ended_at' => $startedAt?->copy()->addMinutes(5),
            'duration_seconds' => 300,
        ], $overrides));

        if ($withRecording) {
            CallRecording::query()->create([
                'call_id' => $call->id,
                'source_url' => 'https://pbx.example/'.$call->id.'.wav',
                'storage_disk' => 'local',
                'storage_path' => 'recordings/'.$call->id.'.wav',
                'status' => 'completed',
                'is_expired' => false,
            ]);
        }

        return $call;
    }
}
