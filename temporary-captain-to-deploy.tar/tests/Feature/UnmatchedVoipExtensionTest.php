<?php

namespace Tests\Feature;

use App\Application\Call\Services\UnmatchedVoipExtensionService;
use App\Application\Intelligence\Jobs\AnalyzeAudioJob;
use App\Application\Intelligence\Jobs\SyncCrmJob;
use App\Application\Intelligence\Jobs\UpdateEmployeeMetricsJob;
use App\Domain\Call\Enums\ConversationSource;
use App\Domain\Llm\Enums\AnalysisSentiment;
use App\Domain\Voip\Enums\VoipLogStatus;
use App\Domain\Voip\Enums\VoipOperation;
use App\Domain\Voip\Enums\VoipProviderCode;
use App\Enums\UserRole;
use App\Infrastructure\Voip\Adapters\NullVoipAdapter;
use App\Livewire\Employer\Intelligence\Show as IntelligenceShow;
use App\Livewire\Employer\Voip\Extensions;
use App\Models\Call;
use App\Models\ConversationAnalysis;
use App\Models\EmployeeIntegrationMeta;
use App\Models\Organization;
use App\Models\OrganizationUser;
use App\Models\OrganizationVoipConnection;
use App\Models\PlatformAiSettings;
use App\Models\User;
use App\Models\VoipCallLog;
use App\Models\VoipProvider;
use App\Services\EmployeeIntegrationMetaService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Bus;
use Illuminate\Validation\ValidationException;
use Livewire\Livewire;
use Tests\TestCase;

class UnmatchedVoipExtensionTest extends TestCase
{
    use RefreshDatabase;

    public function test_assign_extension_writes_meta_and_backfills_calls(): void
    {
        [$organization, $connection, $employer, $employee] = $this->setupOrganization();

        $log = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['extension' => '101', 'resolved_extension' => '101'],
        ]);

        Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '101',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        $backfilled = app(UnmatchedVoipExtensionService::class)->assignExtensionToEmployee(
            organization: $organization,
            extension: '101',
            connectionId: $connection->id,
            organizationUserId: $employee->id,
        );

        $this->assertSame(1, $backfilled);
        $this->assertDatabaseHas('employee_integration_meta', [
            'organization_user_id' => $employee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);
        $this->assertDatabaseHas('calls', [
            'voip_call_log_id' => $log->id,
            'organization_user_id' => $employee->id,
        ]);
    }

    public function test_assign_extension_rejects_conflict_with_other_employee(): void
    {
        [$organization, $connection, , $employee] = $this->setupOrganization();
        $otherEmployee = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => User::factory()->create(['role' => UserRole::Employee])->id,
            'first_name' => 'Sara',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $otherEmployee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        $this->expectException(ValidationException::class);

        app(UnmatchedVoipExtensionService::class)->assignExtensionToEmployee(
            organization: $organization,
            extension: '101',
            connectionId: $connection->id,
            organizationUserId: $employee->id,
        );
    }

    public function test_livewire_assign_unmatched_extension_works_when_gate_disabled(): void
    {
        [$organization, $connection, $employer, $employee] = $this->setupOrganization(selfService: false);

        $log = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '101',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        $this->actingAs($employer);

        Livewire::test(Extensions::class)
            ->set('newExtension', '101')
            ->set('newConnectionId', $connection->id)
            ->set('newEmployeeId', $employee->id)
            ->call('addExtension')
            ->assertHasNoErrors()
            ->assertSuccessful();

        $this->assertDatabaseHas('employee_integration_meta', [
            'organization_user_id' => $employee->id,
            'key' => 'extension',
            'value' => '101',
        ]);
        $this->assertDatabaseHas('calls', [
            'voip_call_log_id' => $log->id,
            'organization_user_id' => $employee->id,
        ]);
    }

    public function test_livewire_assign_unmatched_extension_backfills_when_gate_enabled(): void
    {
        [$organization, $connection, $employer, $employee] = $this->setupOrganization(selfService: true);

        $log = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '101',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        $this->actingAs($employer);

        Livewire::test(Extensions::class)
            ->set('newExtension', '101')
            ->set('newConnectionId', $connection->id)
            ->set('newEmployeeId', $employee->id)
            ->call('addExtension')
            ->assertHasNoErrors();

        $this->assertDatabaseHas('calls', [
            'voip_call_log_id' => $log->id,
            'organization_user_id' => $employee->id,
        ]);
    }

    public function test_assign_extension_also_updates_conversation_analyses(): void
    {
        [$organization, $connection, , $employee] = $this->setupOrganization();

        $log = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-analysis-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        $call = Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-analysis-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '101',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        $analysis = ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => null,
            'call_id' => $call->id,
            'voip_call_log_id' => $log->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 80,
            'summary' => 'test',
            'sentiment' => AnalysisSentiment::Neutral,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => [],
            'analyzed_at' => now(),
        ]);

        app(UnmatchedVoipExtensionService::class)->assignExtensionToEmployee(
            organization: $organization,
            extension: '101',
            connectionId: $connection->id,
            organizationUserId: $employee->id,
        );

        $this->assertSame($employee->id, $analysis->fresh()->organization_user_id);
        $this->assertSame($employee->id, $call->fresh()->organization_user_id);
    }

    public function test_intelligence_show_assigns_employee_without_integration_gate(): void
    {
        [$organization, $connection, $employer, $employee] = $this->setupOrganization(selfService: false);

        $log = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-show-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        $call = Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-show-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '101',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        $analysis = ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => null,
            'call_id' => $call->id,
            'voip_call_log_id' => $log->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 80,
            'summary' => 'test',
            'sentiment' => AnalysisSentiment::Neutral,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => [],
            'cost' => 0,
            'total_tokens' => 0,
            'analyzed_at' => now(),
        ]);

        $this->actingAs($employer);

        Livewire::test(IntelligenceShow::class, ['analysis' => $analysis])
            ->set('assignEmployeeId', $employee->id)
            ->call('assignCallEmployee')
            ->assertHasNoErrors();

        $this->assertSame($employee->id, $analysis->fresh()->organization_user_id);
        $this->assertSame($employee->id, $call->fresh()->organization_user_id);
        $this->assertDatabaseHas('employee_integration_meta', [
            'organization_user_id' => $employee->id,
            'value' => '101',
        ]);
    }

    public function test_sync_employee_extension_backfills_existing_calls(): void
    {
        [$organization, $connection, , $employee] = $this->setupOrganization();

        $log = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-sync-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '982191093492',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['extension' => '101'],
        ]);

        Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-sync-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '982191093492',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        EmployeeIntegrationMetaService::syncForEmployee($employee, [[
            'connection' => EmployeeIntegrationMetaService::connectionReference($connection),
            'meta' => ['extension' => '101'],
        ]]);

        $this->assertDatabaseHas('calls', [
            'voip_call_log_id' => $log->id,
            'organization_user_id' => $employee->id,
        ]);
    }

    public function test_sync_employee_extension_backfills_old_unassigned_calls_beyond_two_weeks(): void
    {
        [$organization, $connection, , $employee] = $this->setupOrganization();

        $oldLog = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-old-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '982191093492',
            'status' => 'completed',
            'started_at' => now()->subDays(45),
            'raw_payload' => ['extension' => '101'],
        ]);

        Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $oldLog->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-old-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '982191093492',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        EmployeeIntegrationMetaService::syncForEmployee($employee, [[
            'connection' => EmployeeIntegrationMetaService::connectionReference($connection),
            'meta' => ['extension' => '101'],
        ]]);

        $this->assertDatabaseHas('calls', [
            'voip_call_log_id' => $oldLog->id,
            'organization_user_id' => $employee->id,
        ]);
    }

    public function test_extensions_page_adds_and_assigns_employee(): void
    {
        [$organization, $connection, $employer, $employee] = $this->setupOrganization();

        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-page-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        $this->actingAs($employer);

        Livewire::test(Extensions::class)
            ->assertSee('داخلی‌ها')
            ->assertSee('افزودن داخلی')
            ->assertDontSee('ثبت داخلی')
            ->assertSee('هنوز داخلی‌ای ثبت نشده')
            ->assertDontSee('شماره داخلی 101 هنوز کارشناس ندارد')
            ->assertDontSee('این داخلی مال کدام کارشناس است؟')
            ->assertDontSee('چه کاری باید انجام دهید؟')
            ->call('toggleAddForm')
            ->assertSee('ثبت داخلی')
            ->set('newExtension', '101')
            ->set('newConnectionId', $connection->id)
            ->set('newEmployeeId', $employee->id)
            ->call('addExtension')
            ->assertHasNoErrors();

        $this->assertDatabaseHas('employee_integration_meta', [
            'organization_user_id' => $employee->id,
            'value' => '101',
        ]);

        Livewire::test(Extensions::class)
            ->assertSee('101')
            ->assertSee('Ali Agent')
            ->assertSee('Asterisk')
            ->assertDontSee('هنوز داخلی‌ای ثبت نشده');
    }

    public function test_extensions_empty_state_is_plain_language(): void
    {
        [, , $employer] = $this->setupOrganization();

        $this->actingAs($employer);

        Livewire::test(Extensions::class)
            ->assertSee('هنوز داخلی‌ای ثبت نشده')
            ->assertSee('اولین شماره داخلی را وارد کنید')
            ->assertDontSee('فعلاً داخلی بدون کارشناس نیست')
            ->assertDontSee('نگاشت شده‌اند');
    }

    public function test_extensions_page_does_not_auto_detect_from_voip_logs(): void
    {
        [$organization, $connection, $employer] = $this->setupOrganization();

        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-auto-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        $this->actingAs($employer);

        Livewire::test(Extensions::class)
            ->assertSee('هنوز داخلی‌ای ثبت نشده')
            ->assertDontSee('101');
    }

    public function test_extensions_page_can_reassign_and_delete(): void
    {
        [$organization, $connection, $employer, $employee] = $this->setupOrganization();
        $otherEmployee = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => User::factory()->create(['role' => UserRole::Employee])->id,
            'first_name' => 'Sara',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $employee->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '101',
        ]);

        $this->actingAs($employer);

        Livewire::test(Extensions::class)
            ->set('employeeSelections.101__'.$connection->id, $otherEmployee->id)
            ->call('updateEmployee', '101', $connection->id)
            ->assertHasNoErrors();

        $this->assertDatabaseHas('employee_integration_meta', [
            'organization_user_id' => $otherEmployee->id,
            'value' => '101',
        ]);
        $this->assertDatabaseMissing('employee_integration_meta', [
            'organization_user_id' => $employee->id,
            'value' => '101',
        ]);

        Livewire::test(Extensions::class)
            ->call('deleteExtension', '101', $connection->id)
            ->assertHasNoErrors();

        $this->assertDatabaseMissing('employee_integration_meta', [
            'value' => '101',
            'integratable_id' => $connection->id,
        ]);
    }

    public function test_assign_extension_queues_recorded_calls_for_analysis(): void
    {
        Bus::fake();
        PlatformAiSettings::current()->update(['allow_negative_balance' => true]);

        [$organization, $connection, , $employee] = $this->setupOrganization();

        $log = VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-queue-1',
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '101',
            'status' => 'completed',
            'started_at' => now()->subDay(),
            'recording_url' => 'https://example.test/recordings/call-queue-1.wav',
            'raw_payload' => ['resolved_extension' => '101'],
        ]);

        Call::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'call-queue-1',
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '101',
            'status' => 'completed',
            'organization_user_id' => null,
        ]);

        app(UnmatchedVoipExtensionService::class)->assignExtensionToEmployee(
            organization: $organization,
            extension: '101',
            connectionId: $connection->id,
            organizationUserId: $employee->id,
        );

        $call = Call::query()->where('voip_call_log_id', $log->id)->first();

        $this->assertNotNull($call);
        $this->assertSame($employee->id, $call->organization_user_id);
        $this->assertDatabaseHas('call_processing_jobs', [
            'call_id' => $call->id,
            'organization_user_id' => $employee->id,
        ]);
        Bus::assertChained([
            AnalyzeAudioJob::class,
            UpdateEmployeeMetricsJob::class,
            SyncCrmJob::class,
        ]);
    }

    /**
     * @return array{0: Organization, 1: OrganizationVoipConnection, 2: User, 3: OrganizationUser}
     */
    private function setupOrganization(bool $selfService = true): array
    {
        $employer = User::factory()->create(['role' => UserRole::Employer]);
        $factory = Organization::factory();

        if ($selfService) {
            $factory = $factory->withIntegrationSelfService();
        }

        $organization = $factory->create(['user_id' => $employer->id]);
        $provider = VoipProvider::query()->create([
            'name' => 'Custom',
            'code' => VoipProviderCode::Custom->value,
            'adapter_class' => NullVoipAdapter::class,
            'is_active' => true,
        ]);
        $connection = OrganizationVoipConnection::query()->create([
            'organization_id' => $organization->id,
            'voip_provider_id' => $provider->id,
            'name' => 'Asterisk',
            'credentials' => [],
            'webhook_token' => str_repeat('a', 48),
            'is_default' => true,
            'is_active' => true,
            'ingestion_mode' => 'webhook',
        ]);
        $connection->syncLogs()->create([
            'operation' => VoipOperation::TestConnection,
            'status' => VoipLogStatus::Success,
            'message' => 'OK',
        ]);
        $employee = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => User::factory()->create(['role' => UserRole::Employee])->id,
            'first_name' => 'Ali',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        return [$organization, $connection, $employer, $employee];
    }
}
