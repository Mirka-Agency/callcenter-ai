<?php

namespace Tests\Unit;

use App\Application\Voip\Services\AsteriskAmiCallTracker;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class AsteriskAmiCallTrackerTest extends TestCase
{
    private AsteriskAmiCallTracker $tracker;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tracker = new AsteriskAmiCallTracker;
    }

    #[Test]
    public function it_builds_payload_from_hangup_event(): void
    {
        $this->tracker->handle([
            'Event' => 'Newchannel',
            'Uniqueid' => '1730000000.1',
            'Linkedid' => '1730000000.1',
            'CallerIDNum' => '09121234567',
            'Context' => 'from-trunk',
            'Exten' => '101',
        ]);

        $this->tracker->handle([
            'Event' => 'Dial',
            'SubEvent' => 'End',
            'Uniqueid' => '1730000000.1',
            'Linkedid' => '1730000000.1',
            'DialStatus' => 'ANSWER',
            'DestCallerIDNum' => '101',
        ]);

        $payload = $this->tracker->handle([
            'Event' => 'Hangup',
            'Uniqueid' => '1730000000.1',
            'Linkedid' => '1730000000.1',
            'CallerIDNum' => '09121234567',
            'Cause-txt' => 'Normal Clearing',
            'BillableSeconds' => '45',
        ]);

        $this->assertNotNull($payload);
        $this->assertSame('call.ended', $payload['event']);
        $this->assertSame('1730000000.1', $payload['call_id']);
        $this->assertSame('09121234567', $payload['from']);
        $this->assertSame('101', $payload['extension']);
        $this->assertSame(45, $payload['duration']);
        $this->assertSame('inbound', $payload['direction']);
    }

    #[Test]
    public function it_builds_payload_from_cdr_event(): void
    {
        $payload = $this->tracker->handle([
            'Event' => 'Cdr',
            'UniqueID' => '1730000001.2',
            'LinkedID' => '1730000001.2',
            'Source' => '101',
            'Destination' => '09129876543',
            'Disposition' => 'ANSWERED',
            'Billsec' => '120',
        ]);

        $this->assertNotNull($payload);
        $this->assertSame('1730000001.2', $payload['call_id']);
        $this->assertSame('101', $payload['from']);
        $this->assertSame('09129876543', $payload['to']);
        $this->assertSame('101', $payload['extension']);
        $this->assertSame(120, $payload['duration']);
        $this->assertSame('outbound', $payload['direction']);
    }

    #[Test]
    public function it_builds_outbound_payload_from_from_internal_hangup(): void
    {
        $this->tracker->handle([
            'Event' => 'Newchannel',
            'Uniqueid' => '1730000003.4',
            'Linkedid' => '1730000003.4',
            'CallerIDNum' => '102',
            'Context' => 'from-internal',
            'Exten' => '09121112233',
        ]);

        $this->tracker->handle([
            'Event' => 'Dial',
            'Uniqueid' => '1730000003.4',
            'Linkedid' => '1730000003.4',
            'DialStatus' => 'ANSWER',
            'DestCallerIDNum' => '09121112233',
        ]);

        $payload = $this->tracker->handle([
            'Event' => 'Hangup',
            'Uniqueid' => '1730000003.4',
            'Linkedid' => '1730000003.4',
            'CallerIDNum' => '102',
            'Cause-txt' => 'Normal Clearing',
            'BillableSeconds' => '30',
        ]);

        $this->assertNotNull($payload);
        $this->assertSame('outbound', $payload['direction']);
        $this->assertSame('102', $payload['from']);
        $this->assertSame('102', $payload['extension']);
        $this->assertSame('09121112233', $payload['to']);
        $this->assertSame(30, $payload['duration']);
    }

    #[Test]
    public function it_maps_cdr_recordingfile_to_http_url(): void
    {
        config(['voip.recordings_public_base' => 'http://192.168.2.16/mirka-call-recordings']);

        $payload = $this->tracker->handle([
            'Event' => 'Cdr',
            'UniqueID' => '1789898636.33122',
            'LinkedID' => '1789898636.33122',
            'Source' => '111',
            'Destination' => '909123438047',
            'Disposition' => 'ANSWERED',
            'Billsec' => '40',
            'recordingfile' => '/var/spool/asterisk/monitor/2026/09/20/out-909123438047-111-20260920-143356-1789898636.33122.wav',
        ]);

        $this->assertNotNull($payload);
        $this->assertSame(
            'http://192.168.2.16/mirka-call-recordings/2026/09/20/out-909123438047-111-20260920-143356-1789898636.33122.wav',
            $payload['recording_url'],
        );
    }

    #[Test]
    public function it_does_not_ingest_twice_for_same_call(): void
    {
        $hangup = [
            'Event' => 'Hangup',
            'Uniqueid' => '1730000002.3',
            'Linkedid' => '1730000002.3',
            'CallerIDNum' => '09120000000',
            'Cause-txt' => 'Normal Clearing',
        ];

        $this->assertNotNull($this->tracker->handle($hangup));
        $this->assertNull($this->tracker->handle($hangup));
    }
}
