<?php

namespace Tests\Unit;

use App\Domain\Call\Enums\ConversationSource;
use App\Domain\Llm\Enums\AnalysisSentiment;
use App\Domain\Processing\Enums\ProcessingJobStatus;
use App\Domain\Voip\Enums\CallStatus;
use App\Domain\Voip\Enums\VoipProviderCode;
use App\DTOs\AnalysisListFilter;
use App\DTOs\ReportFilter;
use App\Enums\ReportDatePreset;
use App\Infrastructure\Voip\Adapters\NullVoipAdapter;
use App\Models\Call;
use App\Models\CallProcessingJob;
use App\Models\CallRecording;
use App\Models\ConversationAnalysis;
use App\Models\EmployeeIntegrationMeta;
use App\Models\Organization;
use App\Models\OrganizationUser;
use App\Models\OrganizationVoipConnection;
use App\Models\User;
use App\Models\VoipCallLog;
use App\Models\VoipProvider;
use App\Services\AnalysisListQuery;
use App\Services\CallIntake\CallIntakeSettings;
use App\Services\CallIntake\Filters\InternalAgentCallsFilter;
use App\Services\CallIntake\Filters\UnassignedAgentCallsFilter;
use App\Services\Performance\EmployeePerformanceAnalytics;
use App\Services\Reports\ProcessingQueueCallStats;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AnalysisListQueryTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Carbon::setTestNow(Carbon::parse('2026-09-16 12:00:00', 'UTC'));
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();

        parent::tearDown();
    }

    public function test_filters_by_agent_status_and_duration(): void
    {
        $organization = Organization::factory()->create();
        $userA = User::factory()->create();
        $userB = User::factory()->create();
        $agentA = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userA->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);
        $agentB = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userB->id,
            'first_name' => 'Sara',
            'last_name' => 'Two',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agentA, 'completed', 300, 90);
        $this->seedAnalysis($organization, $agentA, 'missed', 30, 50);
        $this->seedAnalysis($organization, $agentB, 'completed', 600, 80);

        $filter = AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
            employeeId: $agentA->id,
            statuses: [CallStatus::Completed->value],
            minDurationSeconds: 120,
        );

        $results = app(AnalysisListQuery::class)->paginate($filter);

        $this->assertSame(1, $results->total());
        $this->assertSame(90, $results->first()->score);
    }

    public function test_overview_resolves_top_agent_with_grouped_aggregate(): void
    {
        $organization = Organization::factory()->create();
        $userA = User::factory()->create();
        $userB = User::factory()->create();
        $agentA = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userA->id,
            'first_name' => 'Ali',
            'last_name' => 'Top',
            'is_active' => true,
        ]);
        $agentB = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userB->id,
            'first_name' => 'Sara',
            'last_name' => 'Second',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agentA, 'completed', 300, 90);
        $this->seedAnalysis($organization, $agentA, 'completed', 300, 85);
        $this->seedAnalysis($organization, $agentB, 'completed', 300, 80);

        $filter = AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        );

        $overview = app(AnalysisListQuery::class)->overview($filter);

        $this->assertSame('Ali Top', $overview['top_agent_name']);
        $this->assertSame(2, $overview['top_agent_count']);
        $this->assertSame(3, $overview['total']);
        $this->assertSame(3, $overview['total_leads']);
    }

    public function test_average_lead_score_includes_low_medium_and_high_leads(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agent, 'completed', 300, 90, leadQuality: ['score' => 90, 'level' => 'high', 'reason' => 'test']);
        $this->seedAnalysis($organization, $agent, 'completed', 300, 80, leadQuality: ['score' => 30, 'level' => 'low', 'reason' => 'test']);

        $overview = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(60.0, $overview['average_lead_score']);
    }

    public function test_average_sentiment_ignores_non_evaluable_analyses_like_dashboard(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);

        // Business call: positive (100). Personal/non-evaluable: neutral (50) must not dilute the KPI.
        $this->seedAnalysis(
            $organization,
            $agent,
            'completed',
            300,
            90,
            sentiment: AnalysisSentiment::Positive,
        );
        $this->seedAnalysis(
            $organization,
            $agent,
            'completed',
            40,
            0,
            leadQuality: ['score' => 0, 'level' => 'low', 'reason' => ''],
            sentiment: AnalysisSentiment::Neutral,
            isEvaluable: false,
        );

        $filter = AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        );
        $overview = app(AnalysisListQuery::class)->overview($filter);
        $dashboard = app(EmployeePerformanceAnalytics::class)
            ->teamDashboard(ReportFilter::make($organization->id, ReportDatePreset::Last30));

        $this->assertSame(100.0, $overview['average_sentiment']);
        $this->assertSame(100.0, $dashboard['kpis']['average_sentiment']);
        $this->assertSame($dashboard['kpis']['average_quality_score'], $overview['average_score']);
        $this->assertSame($dashboard['kpis']['average_lead_score'], $overview['average_lead_score']);
    }

    public function test_overview_analyzed_counts_only_finished_analyses(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agent, 'completed', 300, 90);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09121111111',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'pending',
            'duration_seconds' => 120,
            'started_at' => now(),
        ]);

        $overview = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(1, $overview['total'], 'only the call that was actually analyzed');
        $this->assertSame(0, $overview['missed_count']);
        $this->assertSame(0, $overview['outside_analysis_count']);
    }

    public function test_overview_counts_unanalyzed_missed_calls(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agent, 'completed', 300, 90);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09121111111',
            'receiver_number' => '02100000000',
            'status' => CallStatus::Missed->value,
            'processing_status' => 'pending',
            'duration_seconds' => 0,
            'started_at' => now(),
        ]);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => null,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09122222222',
            'receiver_number' => '101',
            'status' => CallStatus::Missed->value,
            'processing_status' => 'pending',
            'duration_seconds' => 0,
            'started_at' => now(),
        ]);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09123333333',
            'receiver_number' => '102',
            'status' => CallStatus::Busy->value,
            'processing_status' => 'pending',
            'duration_seconds' => 0,
            'started_at' => now(),
        ]);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09124444444',
            'receiver_number' => '103',
            'status' => CallStatus::Cancelled->value,
            'processing_status' => 'pending',
            'duration_seconds' => 0,
            'started_at' => now(),
        ]);

        $overview = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
            assignedEmployeesOnly: true,
        ));

        $this->assertSame(1, $overview['total'], 'only the call that was actually analyzed');
        $this->assertSame(4, $overview['missed_count']);
        $this->assertSame(0, $overview['outside_analysis_count']);
    }

    public function test_overview_cards_follow_call_date_not_analysis_completion(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);

        // Analyzed today, but the call happened 42 days ago → outside the call-date window.
        $oldCall = $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000001',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'analyzed',
            'duration_seconds' => 200,
            'started_at' => now()->subDays(42),
            'conversation_date' => now()->subDays(42),
        ]);
        ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'call_id' => $oldCall->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 88,
            'summary' => 'تحلیل امروز برای تماس قدیمی',
            'sentiment' => AnalysisSentiment::Positive,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => [],
            'lead_quality_json' => ['score' => 80, 'level' => 'high', 'reason' => 'test'],
            'analyzed_at' => now(),
        ]);

        // Call in Last30, never analyzed — must count in the direction split.
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'outbound',
            'caller_number' => '02100000000',
            'receiver_number' => '09120000002',
            'status' => 'completed',
            'processing_status' => 'pending',
            'duration_seconds' => 100,
            'started_at' => now()->subDays(2),
        ]);

        // conversation_date in range, started_at outside — still a Last30 call.
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000003',
            'receiver_number' => '02100000000',
            'status' => CallStatus::Missed->value,
            'processing_status' => 'pending',
            'duration_seconds' => 0,
            'started_at' => now()->subDays(60),
            'conversation_date' => now()->subDays(1),
        ]);

        $overview = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(0, $overview['total'], 'an older call analyzed today is not one of the calls in the window');
        $this->assertSame(1, $overview['inbound_count']);
        $this->assertSame(1, $overview['outbound_count']);
        $this->assertSame(1, $overview['missed_count']);
        $this->assertSame(0, $overview['outside_analysis_count']);
        $this->assertSame(100, $overview['average_duration_seconds']);
    }

    public function test_overview_analyzed_counts_calls_in_window_and_ignores_stale_queue_flags(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agent, 'completed', 300, 90);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000020',
            'receiver_number' => '02100000000',
            'status' => CallStatus::Missed->value,
            'processing_status' => 'pending',
            'duration_seconds' => 0,
            'started_at' => now(),
        ]);

        $oldCall = $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000021',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'analyzed',
            'duration_seconds' => 180,
            'started_at' => now()->subDays(50),
            'conversation_date' => now()->subDays(50),
        ]);
        ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'call_id' => $oldCall->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 70,
            'summary' => 'تحلیل تماس خارج از بازه',
            'sentiment' => AnalysisSentiment::Neutral,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => [],
            'analyzed_at' => now(),
        ]);

        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000022',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'pending',
            'duration_seconds' => 90,
            'started_at' => now(),
        ]);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000023',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'skipped',
            'duration_seconds' => 40,
            'started_at' => now(),
        ]);

        $filter = AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        );

        $stale = $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000024',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'analyzed',
            'duration_seconds' => 120,
            'started_at' => now(),
        ]);
        CallProcessingJob::query()->create([
            'job_uuid' => (string) str()->uuid(),
            'call_id' => $stale->id,
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'file_name' => 'stale.wav',
            'status' => ProcessingJobStatus::Completed,
            'progress_percentage' => 100,
            'completed_at' => now(),
        ]);

        $overview = app(AnalysisListQuery::class)->overview($filter);

        $this->assertSame(1, $overview['total'], 'only calls in the window with an analysis row; the older call and the stale "analyzed" flag do not count');
        $this->assertSame(1, $overview['missed_count']);
        $this->assertSame(1, $overview['in_flight_count']);
        $this->assertSame(0, $overview['outside_analysis_count']);

        $queueAllTime = app(ProcessingQueueCallStats::class)->forOrganization($organization->id);
        $this->assertSame(3, $queueAllTime['completed'], 'queue card stays all-time and still counts a call whose analysis row is gone');
    }

    public function test_overview_total_calls_follows_profile_intake_filters(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);
        $connection = $this->voipConnection($organization, [
            '41909000' => '111',
        ]);

        EmployeeIntegrationMeta::query()->create([
            'organization_user_id' => $agent->id,
            'integratable_type' => OrganizationVoipConnection::class,
            'integratable_id' => $connection->id,
            'key' => 'extension',
            'value' => '111',
        ]);

        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'defined-destination',
            'direction' => 'inbound',
            'source_number' => '09120000001',
            'destination_number' => '111',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 100,
        ]);
        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'defined-missed',
            'direction' => 'inbound',
            'source_number' => '09120000002',
            'destination_number' => '111',
            'status' => CallStatus::Missed->value,
            'duration_seconds' => 0,
        ]);
        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'defined-outbound',
            'direction' => 'outbound',
            'source_number' => '111',
            'destination_number' => '09120000003',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 80,
            'raw_payload' => ['resolved_extension' => '111'],
        ]);
        $this->createDirectExtensionCall($organization, $agent, $connection, '111', [
            'direction' => 'outbound',
            'duration_seconds' => 40,
        ]);
        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'defined-recording',
            'direction' => 'inbound',
            'source_number' => '09120000099',
            'destination_number' => '5001',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 50,
            'recording_url' => 'https://pbx.example/monitor/exten-111-20260926.wav',
        ]);
        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'defined-did-alias',
            'direction' => 'inbound',
            'source_number' => '09120000004',
            'destination_number' => '41909000',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 60,
        ]);

        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'undefined-112',
            'direction' => 'inbound',
            'source_number' => '09120000005',
            'destination_number' => '112',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 400,
        ]);
        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'undefined-missed-112',
            'direction' => 'inbound',
            'source_number' => '09120000006',
            'destination_number' => '112',
            'status' => CallStatus::Missed->value,
            'duration_seconds' => 0,
        ]);
        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'prefix-1111',
            'direction' => 'inbound',
            'source_number' => '09120000007',
            'destination_number' => '1111',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 30,
        ]);
        $this->createDirectExtensionCall($organization, $agent, $connection, '112', [
            'direction' => 'inbound',
            'duration_seconds' => 20,
        ]);
        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Imported,
            'provider_code' => 'demo',
            'external_call_id' => 'no-extension',
            'direction' => 'inbound',
            'caller_number' => '09120000008',
            'receiver_number' => '02100000000',
            'status' => CallStatus::Completed->value,
            'processing_status' => 'analyzed',
            'duration_seconds' => 10,
            'started_at' => now(),
        ]);

        $this->createExtensionCall($organization, $agent, $connection, [
            'external_call_id' => 'defined-without-recording',
            'direction' => 'inbound',
            'source_number' => '09120000010',
            'destination_number' => '111',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 90,
            'recording_url' => null,
        ]);
        VoipCallLog::query()->create([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => 'cdr-only-no-answer',
            'direction' => 'outbound',
            'source_number' => '111',
            'destination_number' => '09120000011',
            'status' => CallStatus::Missed->value,
            'started_at' => now(),
            'duration' => 0,
            'raw_payload' => ['source' => 'cdr'],
        ]);

        $overview = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(0, $overview['total'], 'none of these calls have been analyzed');
        $this->assertSame(0, $overview['outside_analysis_count'], 'both profile filters are on, so unregistered extensions stay in the total');
        $this->assertSame(3, $overview['missed_count'], 'an unanswered PBX call without a Call row is still missed');
        $this->assertSame(8, $overview['in_flight_count'], 'a pending call without a recording is never queued, so it is not in flight');
        $this->assertSame(10, $overview['total_calls'], 'with both profile filters on, every PBX call log still counts; uploads without a log do not');
    }

    public function test_overview_partitions_missed_and_agent_to_agent_calls_by_call_date(): void
    {
        $organization = Organization::factory()->create();
        $userA = User::factory()->create();
        $userB = User::factory()->create();
        $agentA = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userA->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);
        $agentB = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userB->id,
            'first_name' => 'Sara',
            'last_name' => 'Two',
            'is_active' => true,
        ]);
        $connection = $this->voipConnection($organization);

        foreach ([[$agentA, '111'], [$agentB, '112']] as [$agent, $extension]) {
            EmployeeIntegrationMeta::query()->create([
                'organization_user_id' => $agent->id,
                'integratable_type' => OrganizationVoipConnection::class,
                'integratable_id' => $connection->id,
                'key' => 'extension',
                'value' => $extension,
            ]);
        }

        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'customer-completed',
            'source_number' => '09120000001',
            'destination_number' => '111',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 90,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'customer-busy',
            'source_number' => '09120000002',
            'destination_number' => '111',
            'status' => CallStatus::Busy->value,
            'duration_seconds' => 0,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'customer-no-agent',
            'source_number' => '09120000003',
            'destination_number' => '111',
            'status' => CallStatus::Missed->value,
            'duration_seconds' => 0,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'customer-queue',
            'source_number' => '09120000004',
            'destination_number' => '111',
            'status' => CallStatus::Ringing->value,
            'duration_seconds' => 0,
            'raw_payload' => ['disposition' => 'ABANDON', 'queue' => 'sales'],
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'agent-to-agent',
            'source_number' => '111',
            'destination_number' => '112',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 40,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'agent-busy',
            'source_number' => '111',
            'destination_number' => '112',
            'status' => CallStatus::Busy->value,
            'duration_seconds' => 0,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'unknown-extension',
            'source_number' => '09120000005',
            'destination_number' => '199',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 30,
        ]);
        $old = $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'old-customer',
            'source_number' => '09120000006',
            'destination_number' => '111',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 20,
        ]);
        $old->update([
            'started_at' => now()->subDays(40),
            'conversation_date' => now()->subDays(40),
        ]);
        $old->voipCallLog()->update(['started_at' => now()->subDays(40)]);

        $overview = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(0, $overview['total']);
        $this->assertSame(0, $overview['outside_analysis_count'], 'both profile filters are on');
        $this->assertSame(4, $overview['missed_count']);
        $this->assertSame(7, $overview['total_calls']);
    }

    public function test_overview_outside_analysis_is_zero_when_no_extensions_are_defined(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09121111111',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'pending',
            'duration_seconds' => 120,
            'started_at' => now(),
        ]);

        $overview = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(0, $overview['outside_analysis_count']);
    }

    public function test_overview_cards_follow_disabled_organization_intake_filters(): void
    {
        $organization = Organization::factory()->create();
        $userA = User::factory()->create();
        $userB = User::factory()->create();
        $agentA = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userA->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);
        $agentB = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $userB->id,
            'first_name' => 'Sara',
            'last_name' => 'Two',
            'is_active' => true,
        ]);
        $connection = $this->voipConnection($organization);

        foreach ([[$agentA, '111'], [$agentB, '112']] as [$agent, $extension]) {
            EmployeeIntegrationMeta::query()->create([
                'organization_user_id' => $agent->id,
                'integratable_type' => OrganizationVoipConnection::class,
                'integratable_id' => $connection->id,
                'key' => 'extension',
                'value' => $extension,
            ]);
        }

        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'customer',
            'source_number' => '09120000001',
            'destination_number' => '111',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 90,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'unknown-extension',
            'source_number' => '09120000005',
            'destination_number' => '199',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 30,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'agent-to-agent',
            'source_number' => '111',
            'destination_number' => '112',
            'status' => CallStatus::Completed->value,
            'duration_seconds' => 40,
        ]);
        $this->createExtensionCall($organization, $agentA, $connection, [
            'external_call_id' => 'unknown-extension-no-answer',
            'source_number' => '09120000006',
            'destination_number' => '199',
            'status' => CallStatus::Missed->value,
            'duration_seconds' => 0,
        ]);

        $organization->update([
            'call_intake_filters' => [
                UnassignedAgentCallsFilter::KEY => false,
                InternalAgentCallsFilter::KEY => false,
            ],
        ]);
        app(CallIntakeSettings::class)->forget($organization->id);

        $blocked = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(1, $blocked['total_calls'], 'only the customer call on a registered extension stays in the total');
        $this->assertSame(2, $blocked['outside_analysis_count'], 'an unanswered call is never outside analysis');
        $this->assertSame(1, $blocked['missed_count'], 'an unanswered call is missed even when the filters block its extension');

        $organization->update([
            'call_intake_filters' => [
                UnassignedAgentCallsFilter::KEY => true,
                InternalAgentCallsFilter::KEY => true,
            ],
        ]);
        app(CallIntakeSettings::class)->forget($organization->id);

        $open = app(AnalysisListQuery::class)->overview(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));

        $this->assertSame(4, $open['total_calls']);
        $this->assertSame(0, $open['outside_analysis_count']);
        $this->assertSame(1, $open['missed_count']);
    }

    public function test_assigned_employees_only_excludes_unassigned_analyses(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'Assigned',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agent, 'completed', 300, 90);
        $this->seedUnassignedAnalysis($organization);

        $all = app(AnalysisListQuery::class)->paginate(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
        ));
        $assigned = app(AnalysisListQuery::class)->paginate(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
            assignedEmployeesOnly: true,
        ));

        $this->assertSame(2, $all->total());
        $this->assertSame(1, $assigned->total());
        $this->assertSame($agent->id, $assigned->first()->organization_user_id);
    }

    public function test_filters_calls_that_need_attention(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $agent = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Ali',
            'last_name' => 'One',
            'is_active' => true,
        ]);

        $this->seedAnalysis($organization, $agent, 'completed', 300, 90);
        $attention = $this->seedAnalysis($organization, $agent, 'completed', 240, 40, true);

        $results = app(AnalysisListQuery::class)->paginate(AnalysisListFilter::make(
            organizationId: $organization->id,
            preset: ReportDatePreset::Last30,
            needsAttention: true,
        ));

        $this->assertSame(1, $results->total());
        $this->assertTrue($results->first()->needs_attention);
        $this->assertSame($attention->id, $results->first()->id);
    }

    private function seedUnassignedAnalysis(Organization $organization): void
    {
        $call = $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => null,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09123333333',
            'receiver_number' => '101',
            'status' => 'completed',
            'processing_status' => 'analyzed',
            'duration_seconds' => 60,
            'started_at' => now(),
        ]);

        ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => null,
            'call_id' => $call->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 10,
            'summary' => 'بدون کارشناس',
            'sentiment' => AnalysisSentiment::Neutral,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => [],
            'analyzed_at' => now(),
        ]);
    }

    private function seedAnalysis(
        Organization $organization,
        OrganizationUser $employee,
        string $status,
        int $durationSeconds,
        int $score,
        bool $needsAttention = false,
        ?array $leadQuality = null,
        AnalysisSentiment $sentiment = AnalysisSentiment::Positive,
        ?bool $isEvaluable = null,
    ): ConversationAnalysis {
        $call = $this->makeRecordedCall([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => uniqid('call-', true),
            'direction' => 'inbound',
            'caller_number' => '09120000000',
            'receiver_number' => '02100000000',
            'status' => $status,
            'processing_status' => 'analyzed',
            'duration_seconds' => $durationSeconds,
            'started_at' => now(),
        ]);

        return ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'call_id' => $call->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => $score,
            'is_evaluable' => $isEvaluable ?? $score > 0,
            'summary' => 'خلاصه تست',
            'sentiment' => $sentiment,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => [],
            'lead_quality_json' => $leadQuality ?? ['score' => 70, 'level' => 'medium', 'reason' => 'test'],
            'needs_attention' => $needsAttention,
            'attention_json' => $needsAttention ? [
                'needed' => true,
                'categories' => ['agent'],
                'reason' => 'مشتری به عملکرد کارشناس اعتراض دارد',
            ] : null,
            'analyzed_at' => now(),
        ]);
    }

    /** @param  array<string, string>  $extensionMapping */
    private function voipConnection(Organization $organization, array $extensionMapping = []): OrganizationVoipConnection
    {
        $provider = VoipProvider::query()->create([
            'name' => 'Custom',
            'code' => VoipProviderCode::Custom->value.'-'.$organization->id,
            'adapter_class' => NullVoipAdapter::class,
            'is_active' => true,
        ]);

        return OrganizationVoipConnection::query()->create([
            'organization_id' => $organization->id,
            'voip_provider_id' => $provider->id,
            'name' => 'Asterisk',
            'credentials' => [],
            'settings' => ['extension_mapping' => $extensionMapping],
            'is_default' => true,
            'is_active' => true,
        ]);
    }

    /** @param  array<string, mixed>  $logOverrides */
    private function createExtensionCall(
        Organization $organization,
        OrganizationUser $agent,
        OrganizationVoipConnection $connection,
        array $logOverrides,
    ): Call {
        $log = VoipCallLog::query()->create(array_merge([
            'organization_id' => $organization->id,
            'organization_voip_connection_id' => $connection->id,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => uniqid('log-', true),
            'direction' => 'inbound',
            'source_number' => '09120000000',
            'destination_number' => '111',
            'status' => CallStatus::Completed->value,
            'started_at' => now(),
            'duration' => $logOverrides['duration_seconds'] ?? 0,
            'recording_url' => 'https://pbx.example/rec.wav',
            'raw_payload' => [],
        ], $logOverrides));

        return Call::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'organization_voip_connection_id' => $connection->id,
            'voip_call_log_id' => $log->id,
            'source' => ConversationSource::Voip,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => $log->external_call_id,
            'direction' => $logOverrides['direction'] ?? 'inbound',
            'caller_number' => $log->source_number,
            'receiver_number' => $log->destination_number,
            'status' => $logOverrides['status'] ?? CallStatus::Completed->value,
            'processing_status' => 'pending',
            'duration_seconds' => $logOverrides['duration_seconds'] ?? 0,
            'started_at' => now(),
        ]);
    }

    /** @param  array<string, mixed>  $overrides */
    private function createDirectExtensionCall(
        Organization $organization,
        OrganizationUser $agent,
        OrganizationVoipConnection $connection,
        string $extension,
        array $overrides,
    ): Call {
        $direction = $overrides['direction'] ?? 'inbound';

        return $this->makeRecordedCall(array_merge([
            'organization_id' => $organization->id,
            'organization_user_id' => $agent->id,
            'organization_voip_connection_id' => $connection->id,
            'source' => ConversationSource::Voip,
            'provider_code' => VoipProviderCode::Custom->value,
            'external_call_id' => uniqid('direct-', true),
            'direction' => $direction,
            'caller_number' => $direction === 'outbound' ? $extension : '09121111111',
            'receiver_number' => $direction === 'outbound' ? '09122222222' : $extension,
            'status' => CallStatus::Completed->value,
            'processing_status' => 'pending',
            'duration_seconds' => 0,
            'started_at' => now(),
        ], $overrides));
    }

    /** @param  array<string, mixed>  $attributes */
    private function makeRecordedCall(array $attributes): Call
    {
        $call = Call::query()->create($attributes);

        CallRecording::query()->create([
            'call_id' => $call->id,
            'source_url' => 'https://pbx.example/'.$call->id.'.wav',
            'storage_disk' => 'local',
            'storage_path' => 'recordings/test-'.$call->id.'.wav',
            'status' => 'completed',
            'is_expired' => false,
        ]);

        return $call;
    }
}
