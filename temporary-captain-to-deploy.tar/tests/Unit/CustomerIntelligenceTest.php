<?php

namespace Tests\Unit;

use App\Domain\Call\Enums\ConversationSource;
use App\Domain\Llm\Enums\AnalysisSentiment;
use App\Models\Call;
use App\Models\CallRecording;
use App\Models\ConversationAnalysis;
use App\Models\Customer;
use App\Models\CustomerCompany;
use App\Models\CustomerIdentityReview;
use App\Models\Organization;
use App\Models\OrganizationUser;
use App\Models\User;
use App\Services\CustomerCompanyIntelligenceService;
use App\Services\CustomerIntelligenceService;
use App\Services\CustomerPhoneResolver;
use App\Services\CustomerProfileUpdateService;
use App\Support\CustomerAnalysisVisibility;
use App\Support\CustomerFieldProvenance;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CustomerIntelligenceTest extends TestCase
{
    use RefreshDatabase;

    public function test_phone_resolver_normalizes_digits(): void
    {
        $resolver = app(CustomerPhoneResolver::class);

        $this->assertSame('989121234567', $resolver->normalize('+98 912-123-4567'));
    }

    public function test_sync_creates_customer_grouped_by_phone(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $employee = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Sara',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        $call = Call::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => 'test-call-1',
            'direction' => 'inbound',
            'caller_number' => '09121234567',
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'analyzed',
            'started_at' => now()->subDay(),
        ]);
        $this->attachRecording($call);

        $analysis = ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'call_id' => $call->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 85,
            'summary' => 'خلاصه',
            'sentiment' => AnalysisSentiment::Positive,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => ['پیگیری هفته آینده'],
            'lead_quality_json' => ['score' => 80, 'level' => 'high', 'reason' => 'test'],
            'customer_identity_json' => [
                'person_name' => 'علی رضایی',
                'company_name' => 'آلفا',
                'email' => 'ali@example.com',
                'confidence' => 0.9,
            ],
            'analyzed_at' => now(),
        ]);

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis);

        $this->assertInstanceOf(Customer::class, $customer);
        $this->assertNull($customer->name);
        $this->assertSame('09121234567', $customer->phone_number);
        $this->assertSame('09121234567', $customer->normalized_phone);
        $this->assertNull($customer->customer_company_id);
        $this->assertSame(0, CustomerCompany::query()->where('organization_id', $organization->id)->count());
        $this->assertDatabaseHas('customer_identity_reviews', [
            'organization_id' => $organization->id,
            'kind' => 'field_suggestion',
            'field' => 'name',
            'status' => 'pending',
        ]);
        $this->assertSame(1, $customer->total_calls);
        $this->assertSame($customer->id, $call->fresh()->customer_id);
    }

    public function test_phone_resolver_treats_iranian_number_formats_as_the_same_number(): void
    {
        $resolver = app(CustomerPhoneResolver::class);

        $this->assertSame(
            $this->sortedPhoneKeys(['09121234567', '9121234567', '989121234567', '00989121234567']),
            $this->sortedPhoneKeys($resolver->equivalentKeys('+98 912-123-4567')),
        );
        $this->assertSame(
            $this->sortedPhoneKeys($resolver->equivalentKeys('09121234567')),
            $this->sortedPhoneKeys($resolver->equivalentKeys('00989121234567')),
        );
    }

    public function test_sync_reuses_existing_person_when_the_same_number_is_formatted_differently(): void
    {
        $organization = Organization::factory()->create();
        $first = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'آلفا',
            'confidence' => 0.9,
        ], callerNumber: '09121234567');

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($first);

        $second = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'آلفا',
            'confidence' => 0.8,
        ], callerNumber: '+98 912 123 4567', externalCallId: 'test-call-plus98');

        $reused = app(CustomerIntelligenceService::class)->syncFromAnalysis($second);

        $this->assertSame($customer->id, $reused->id);
        $this->assertSame(1, Customer::query()->where('organization_id', $organization->id)->count());
        $this->assertSame($customer->id, $second->call->fresh()->customer_id);
        $this->assertSame(2, $reused->total_calls);
    }

    public function test_sync_merges_people_already_split_by_equivalent_phone_numbers(): void
    {
        $organization = Organization::factory()->create();
        $older = Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'علی رضایی',
            'phone_number' => '09121234567',
            'normalized_phone' => '09121234567',
        ]);
        Customer::query()->create([
            'organization_id' => $organization->id,
            'phone_number' => '989121234567',
            'normalized_phone' => '989121234567',
        ]);

        $analysis = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'آلفا',
            'confidence' => 0.9,
        ], callerNumber: '00989121234567');

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis);

        $this->assertNull($customer);
        $this->assertSame(2, Customer::query()->where('organization_id', $organization->id)->count());
        $this->assertNull($analysis->call->fresh()->customer_id);
        $this->assertDatabaseHas('customer_identity_reviews', [
            'organization_id' => $organization->id,
            'kind' => 'duplicate_phone',
            'status' => 'pending',
        ]);
    }

    public function test_sync_creates_a_new_person_when_the_number_is_new_even_if_the_name_matches(): void
    {
        $organization = Organization::factory()->create();
        $existing = Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'آقای علی رضایی',
            'phone_number' => '09120000001',
            'normalized_phone' => '09120000001',
        ]);

        $analysis = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'آلفا',
            'confidence' => 0.9,
        ], callerNumber: '09351234567');

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis);

        $this->assertNotSame($existing->id, $customer->id);
        $this->assertSame(2, Customer::query()->where('organization_id', $organization->id)->count());
        $this->assertSame($customer->id, $analysis->call->fresh()->customer_id);
        $this->assertSame('09351234567', $customer->phone_number);
    }

    public function test_sync_does_not_guess_when_several_people_share_the_same_name(): void
    {
        $organization = Organization::factory()->create();
        Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'علی رضایی',
            'phone_number' => '09120000001',
            'normalized_phone' => '09120000001',
        ]);
        Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'علی رضایی',
            'phone_number' => '09120000002',
            'normalized_phone' => '09120000002',
        ]);

        $analysis = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'آلفا',
            'confidence' => 0.95,
        ], callerNumber: '09350000003');

        app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis);

        $this->assertSame(3, Customer::query()->where('organization_id', $organization->id)->count());
    }

    public function test_sync_creates_a_new_person_when_the_number_is_new_even_if_the_email_matches(): void
    {
        $organization = Organization::factory()->create();
        $existing = Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'شخص قبلی',
            'email' => 'ali@example.com',
            'phone_number' => '09120000001',
            'normalized_phone' => '09120000001',
        ]);

        $analysis = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'آلفا',
            'email' => 'Ali@Example.com',
            'confidence' => 0.4,
        ], callerNumber: '09351234567');

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis);

        $this->assertNotSame($existing->id, $customer->id);
        $this->assertSame(2, Customer::query()->where('organization_id', $organization->id)->count());
        $this->assertSame($customer->id, $analysis->call->fresh()->customer_id);
    }

    public function test_sync_does_not_create_a_company_when_the_call_names_none(): void
    {
        $organization = Organization::factory()->create();
        $analysis = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => '',
            'confidence' => 0.9,
        ]);

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis);

        $this->assertInstanceOf(Customer::class, $customer);
        $this->assertNull($customer->customer_company_id);
        $this->assertSame(0, CustomerCompany::query()->where('organization_id', $organization->id)->count());
    }

    public function test_sync_puts_every_caller_who_names_the_company_on_that_company(): void
    {
        $organization = Organization::factory()->create();
        $first = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'شرکت آلفا',
            'confidence' => 0.9,
        ], callerNumber: '09120000001', externalCallId: 'alpha-1');
        $second = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'مریم کریمی',
            'company_name' => 'آلفا',
            'confidence' => 0.8,
        ], callerNumber: '09120000002', externalCallId: 'alpha-2');

        $service = app(CustomerIntelligenceService::class);
        $ali = $service->syncFromAnalysis($first);
        $maryam = $service->syncFromAnalysis($second);

        $this->assertNotSame($ali->id, $maryam->id);
        $this->assertNull($ali->customer_company_id);
        $this->assertNull($maryam->customer_company_id);
        $this->assertSame(0, CustomerCompany::query()->where('organization_id', $organization->id)->count());
        $this->assertSame(2, CustomerIdentityReview::query()
            ->where('organization_id', $organization->id)
            ->where('kind', 'company_candidate')
            ->count());
    }

    public function test_repeat_call_from_the_same_number_is_added_to_the_existing_person(): void
    {
        $organization = Organization::factory()->create();
        $first = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => '',
            'confidence' => 0.9,
        ], callerNumber: '09125556677', externalCallId: 'repeat-1');
        $second = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => '',
            'confidence' => 0.9,
        ], callerNumber: '09125556677', externalCallId: 'repeat-2');
        $second->call->update(['started_at' => now()]);

        $service = app(CustomerIntelligenceService::class);
        $customer = $service->syncFromAnalysis($first);
        $again = $service->syncFromAnalysis($second->fresh(['call']));

        $this->assertSame($customer->id, $again->id);
        $this->assertSame(1, Customer::query()->where('organization_id', $organization->id)->count());
        $this->assertSame(2, $again->total_calls);

        $timeline = $service->timeline($again);
        $this->assertCount(2, $timeline);
        $this->assertNotSame($timeline[0]['date'], '');
        $this->assertSame($again->id, $second->call->fresh()->customer_id);
    }

    public function test_sync_does_not_create_own_organization_as_customer_company(): void
    {
        $organization = Organization::factory()->create(['title' => 'میرکو']);
        $analysis = $this->makeIdentityAnalysis($organization, [
            'company_name' => 'شرکت میرکو',
            'person_name' => 'علی رضایی',
            'confidence' => 0.95,
        ], direction: 'outbound');

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis);

        $this->assertInstanceOf(Customer::class, $customer);
        $this->assertNull($customer->customer_company_id);
        $this->assertNull($customer->company_name);
        $this->assertSame(0, CustomerCompany::query()->where('organization_id', $organization->id)->count());
    }

    public function test_sync_corrects_company_spelling_and_merges_prefixed_duplicates(): void
    {
        $organization = Organization::factory()->create(['title' => 'میرکو']);
        $first = $this->makeIdentityAnalysis($organization, [
            'company_name' => 'شركت آلفا',
            'person_name' => 'علی رضایی',
            'confidence' => 0.7,
        ], callerNumber: '09121234567');

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($first);
        $this->assertNull($customer->customer_company_id);

        $second = $this->makeIdentityAnalysis($organization, [
            'company_name' => 'آلفا',
            'person_name' => 'علی رضایی',
            'confidence' => 0.7,
        ], callerNumber: '09121234567', externalCallId: 'test-call-2');

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($second);

        $this->assertNull($customer->fresh()->customer_company_id);
        $this->assertSame(0, CustomerCompany::query()->where('organization_id', $organization->id)->count());
        $this->assertSame(1, Customer::query()->where('organization_id', $organization->id)->count());
    }

    public function test_personal_call_does_not_create_a_customer(): void
    {
        $organization = Organization::factory()->create();
        $analysis = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'علی رضایی',
            'company_name' => 'آلفا',
            'confidence' => 0.95,
        ]);
        $analysis->update(['is_personal' => true]);

        $customer = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis->fresh());

        $this->assertNull($customer);
        $this->assertSame(0, Customer::query()->where('organization_id', $organization->id)->count());
        $this->assertNull($analysis->call->fresh()->customer_id);
    }

    public function test_human_verified_identity_is_not_overwritten_by_a_newer_ai_suggestion(): void
    {
        $organization = Organization::factory()->create();
        $customer = app(CustomerProfileUpdateService::class)->create($organization->id, [
            'name' => 'نام دستی',
            'email' => 'manual@example.com',
            'job_title' => 'مدیر خرید',
            'company_name' => 'شرکت بتا',
            'phone_number' => '09121234567',
        ]);

        $analysis = $this->makeIdentityAnalysis($organization, [
            'person_name' => 'نام هوش مصنوعی',
            'company_name' => 'شرکت آلفا',
            'email' => 'ai@example.com',
            'confidence' => 0.99,
        ], callerNumber: '09121234567', externalCallId: 'human-lock-call');
        $analysis->update([
            'customer_identity_json' => [
                ...$analysis->customer_identity_json,
                'job_title' => 'کارشناس فروش',
            ],
        ]);

        $enriched = app(CustomerIntelligenceService::class)->syncFromAnalysis($analysis->fresh());

        $this->assertSame($customer->id, $enriched->id);
        $this->assertSame('نام دستی', $enriched->name);
        $this->assertSame('manual@example.com', $enriched->email);
        $this->assertSame('مدیر خرید', $enriched->job_title);
        $this->assertSame('شرکت بتا', $enriched->company_name);
        $this->assertTrue(CustomerFieldProvenance::isHumanLocked($enriched->identity_field_sources, 'name'));
        $this->assertSame($customer->customer_company_id, $enriched->customer_company_id);
        $this->assertSame($enriched->id, $analysis->call->fresh()->customer_id);
    }

    public function test_employee_cannot_view_other_employee_performance(): void
    {
        $organization = Organization::factory()->create();
        $analysis = ConversationAnalysis::query()->make([
            'organization_id' => $organization->id,
            'organization_user_id' => 99,
        ]);

        $this->assertFalse(CustomerAnalysisVisibility::canViewEmployeePerformance(1, $analysis, false));
        $this->assertTrue(CustomerAnalysisVisibility::canViewEmployeePerformance(99, $analysis, false));
        $this->assertTrue(CustomerAnalysisVisibility::canViewEmployeePerformance(null, $analysis, true));
    }

    public function test_aggregated_next_actions_keeps_only_the_five_highest_priority_items(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $employee = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Sara',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        $customer = Customer::query()->create([
            'organization_id' => $organization->id,
            'name' => 'علی رضایی',
            'phone_number' => '09120001111',
            'normalized_phone' => '09120001111',
        ]);

        $this->createCustomerAnalysis($organization, $employee, $customer, [
            'external_call_id' => 'routine-call',
            'analyzed_at' => now(),
            'next_actions_json' => [
                'ارسال کاتالوگ محصول',
                'هماهنگی جلسه معرفی',
                'ارسال لینک آموزش',
                'یادآوری تمدید اشتراک',
                'ثبت یادداشت در سی‌آر‌ام',
                'ارسال نمونه قرارداد',
            ],
        ]);

        $this->createCustomerAnalysis($organization, $employee, $customer, [
            'external_call_id' => 'critical-call',
            'analyzed_at' => now()->subDay(),
            'needs_attention' => true,
            'sentiment' => AnalysisSentiment::Negative,
            'customer_insights_json' => [
                'urgency_level' => 'critical',
                'risk_level' => 'high',
            ],
            'next_actions_json' => ['ثبت تیکت فوری برای قطع سرویس'],
        ]);

        $actions = app(CustomerIntelligenceService::class)->aggregatedNextActions($customer);

        $this->assertCount(5, $actions);
        $this->assertSame('ثبت تیکت فوری برای قطع سرویس', $actions[0]);
        $this->assertNotContains('ارسال نمونه قرارداد', $actions);
    }

    public function test_company_aggregated_next_actions_keeps_only_the_five_highest_priority_items(): void
    {
        $organization = Organization::factory()->create();
        $user = User::factory()->create();
        $employee = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Sara',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        $company = CustomerCompany::query()->create([
            'organization_id' => $organization->id,
            'name' => 'شرکت آلفا',
        ]);

        $firstContact = Customer::query()->create([
            'organization_id' => $organization->id,
            'customer_company_id' => $company->id,
            'name' => 'مخاطب اول',
            'phone_number' => '09120001111',
            'normalized_phone' => '09120001111',
        ]);
        $secondContact = Customer::query()->create([
            'organization_id' => $organization->id,
            'customer_company_id' => $company->id,
            'name' => 'مخاطب دوم',
            'phone_number' => '09120002222',
            'normalized_phone' => '09120002222',
        ]);

        $this->createCustomerAnalysis($organization, $employee, $firstContact, [
            'external_call_id' => 'company-routine',
            'analyzed_at' => now(),
            'next_actions_json' => [
                'ارسال کاتالوگ محصول',
                'هماهنگی جلسه معرفی',
                'ارسال لینک آموزش',
                'یادآوری تمدید اشتراک',
            ],
        ]);

        $this->createCustomerAnalysis($organization, $employee, $secondContact, [
            'external_call_id' => 'company-critical',
            'analyzed_at' => now()->subDay(),
            'needs_attention' => true,
            'sentiment' => AnalysisSentiment::Negative,
            'customer_insights_json' => [
                'urgency_level' => 'high',
                'risk_level' => 'high',
            ],
            'next_actions_json' => [
                'ثبت تیکت فوری برای قطع سرویس',
                'تماس بازخورد امروز ساعت ۱۷',
                'ارسال پیامک وضعیت مرسوله',
            ],
        ]);

        $actions = app(CustomerCompanyIntelligenceService::class)->aggregatedNextActions($company);

        $this->assertCount(5, $actions);
        $this->assertSame('ثبت تیکت فوری برای قطع سرویس', $actions[0]);
        $this->assertContains('تماس بازخورد امروز ساعت ۱۷', $actions);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    private function createCustomerAnalysis(
        Organization $organization,
        OrganizationUser $employee,
        Customer $customer,
        array $data,
    ): ConversationAnalysis {
        $call = Call::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'customer_id' => $customer->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => $data['external_call_id'],
            'direction' => 'inbound',
            'caller_number' => $customer->phone_number,
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'analyzed',
            'started_at' => $data['analyzed_at'],
        ]);
        $this->attachRecording($call);

        return ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'call_id' => $call->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 70,
            'summary' => 'خلاصه تست',
            'sentiment' => $data['sentiment'] ?? AnalysisSentiment::Positive,
            'needs_attention' => $data['needs_attention'] ?? false,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => $data['next_actions_json'],
            'customer_insights_json' => $data['customer_insights_json'] ?? [],
            'analyzed_at' => $data['analyzed_at'],
        ]);
    }

    /**
     * @param  array{company_name: string, person_name?: string, confidence?: float}  $identity
     */
    /** @param  list<string>  $keys
     * @return list<string>
     */
    private function sortedPhoneKeys(array $keys): array
    {
        sort($keys, SORT_STRING);

        return $keys;
    }

    private function attachRecording(Call $call): void
    {
        CallRecording::query()->create([
            'call_id' => $call->id,
            'source_url' => 'https://pbx.example/'.$call->id.'.wav',
            'storage_disk' => 'local',
            'storage_path' => 'recordings/test-'.$call->id.'.wav',
            'status' => 'completed',
            'is_expired' => false,
        ]);
    }

    private function makeIdentityAnalysis(
        Organization $organization,
        array $identity,
        string $direction = 'inbound',
        string $callerNumber = '09121234567',
        string $externalCallId = 'test-call-1',
    ): ConversationAnalysis {
        $user = User::factory()->create();
        $employee = OrganizationUser::query()->create([
            'organization_id' => $organization->id,
            'user_id' => $user->id,
            'first_name' => 'Sara',
            'last_name' => 'Agent',
            'is_active' => true,
        ]);

        $call = Call::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'source' => ConversationSource::Voip,
            'provider_code' => 'novatel',
            'external_call_id' => $externalCallId,
            'direction' => $direction,
            'caller_number' => $callerNumber,
            'receiver_number' => '02100000000',
            'status' => 'completed',
            'processing_status' => 'analyzed',
            'started_at' => now()->subDay(),
        ]);
        $this->attachRecording($call);

        return ConversationAnalysis::query()->create([
            'organization_id' => $organization->id,
            'organization_user_id' => $employee->id,
            'call_id' => $call->id,
            'source' => ConversationSource::Voip,
            'llm_provider' => 'openai',
            'model_name' => 'gpt-4o-mini',
            'score' => 85,
            'summary' => 'خلاصه',
            'sentiment' => AnalysisSentiment::Positive,
            'strengths_json' => [],
            'weaknesses_json' => [],
            'next_actions_json' => [],
            'lead_quality_json' => ['score' => 80, 'level' => 'high', 'reason' => 'test'],
            'customer_identity_json' => [
                'person_name' => $identity['person_name'] ?? 'علی رضایی',
                'company_name' => $identity['company_name'],
                'email' => $identity['email'] ?? '',
                'phone_number' => $identity['phone_number'] ?? '',
                'confidence' => $identity['confidence'] ?? 0.9,
            ],
            'analyzed_at' => now(),
        ]);
    }
}
